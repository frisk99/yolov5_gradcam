"""
OpenClaw Memory System - Python Implementation

A standalone Python implementation of the OpenClaw memory system,
providing short-term memory, long-term memory, and vector database support.

Usage:
    python -m python_memory search <query> --agent-id <id>
    python -m python_memory get <path> --agent-id <id>
    python -m python_memory sync --agent-id <id>
    python -m python_memory status --agent-id <id>
    python -m python_memory ltm store <text> --category <category>
    python -m python_memory ltm search <query>
"""

from .memory_types import (
    MemorySource,
    MemoryCitationsMode,
    MemorySearchResult,
    MemoryProviderStatus,
    MemoryEmbeddingProbeResult,
    MemorySearchManager,
    EmbeddingProviderResult,
    EmbeddingProviderId,
)
from .config import (
    MemoryConfig,
    load_config_from_env,
    load_config_from_dict,
    create_default_config,
)
from .manager import (
    MemoryIndexManager,
    ResolvedMemoryConfig,
)
from .tools import (
    MemorySearchTool,
    MemoryGetTool,
    MemorySearchResponse,
    MemoryGetResponse,
    memory_search,
    memory_get,
)

__version__ = "0.1.0"
__all__ = [
    # Types
    "MemorySource",
    "MemoryCitationsMode",
    "MemorySearchResult",
    "MemoryProviderStatus",
    "MemoryEmbeddingProbeResult",
    "MemorySearchManager",
    "EmbeddingProviderResult",
    "EmbeddingProviderId",
    # Config
    "MemoryConfig",
    "ResolvedMemoryConfig",
    "load_config_from_env",
    "load_config_from_dict",
    "create_default_config",
    # Manager
    "MemoryIndexManager",
    # Tools
    "MemorySearchTool",
    "MemoryGetTool",
    "MemorySearchResponse",
    "MemoryGetResponse",
    "memory_search",
    "memory_get",
]
