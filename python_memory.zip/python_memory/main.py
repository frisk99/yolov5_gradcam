#!/usr/bin/env python3
"""
OpenClaw Memory System - Python Implementation
Main entry point and CLI interface

Usage:
    python -m python_memory search <query> --agent-id <id>
    python -m python_memory get <path> --agent-id <id>
    python -m python_memory sync --agent-id <id>
    python -m python_memory status --agent-id <id>
"""

import asyncio
import argparse
import json
import sys
import os
from typing import Optional

# Note: Using local types module, not Python's built-in 'types'
# Import with fallback for direct script execution
try:
    # Try relative imports first (for `python -m python_memory` usage)
    from .memory_types import MemorySource, MemoryCitationsMode  # type: ignore
    from .config import (  # type: ignore
        MemoryConfig,
        load_config_from_env,
        load_config_from_dict,
        create_default_config,
    )
    from .manager import (  # type: ignore
        MemoryIndexManager,
        ResolvedMemoryConfig as ManagerConfig,
        StoreConfig,
        VectorConfig,
        ChunkingConfig,
        SyncConfig,
        QueryConfig,
        CacheConfig,
    )
    from .tools import (  # type: ignore
        MemorySearchTool,
        MemoryGetTool,
        MemorySearchResponse,
        MemoryGetResponse,
        memory_search,
        memory_get,
    )
    from .memory_lancedb import LanceDBMemory, LanceDBConfig, create_lancedb_memory  # type: ignore
except ImportError:
    # Fallback to direct imports for `python main.py` usage
    from memory_types import MemorySource, MemoryCitationsMode  # type: ignore
    from config import (  # type: ignore
        MemoryConfig,
        load_config_from_env,
        load_config_from_dict,
        create_default_config,
    )
    from manager import (  # type: ignore
        MemoryIndexManager,
        ResolvedMemoryConfig as ManagerConfig,
        StoreConfig,
        VectorConfig,
        ChunkingConfig,
        SyncConfig,
        QueryConfig,
        CacheConfig,
    )
    from tools import (  # type: ignore
        MemorySearchTool,
        MemoryGetTool,
        MemorySearchResponse,
        MemoryGetResponse,
        memory_search,
        memory_get,
    )
    from memory_lancedb import LanceDBMemory, LanceDBConfig, create_lancedb_memory  # type: ignore


def print_json(data: dict) -> None:
    """Print data as formatted JSON"""
    print(json.dumps(data, indent=2, default=str))


def print_table(headers: list[str], rows: list[list[str]]) -> None:
    """Print data as ASCII table"""
    if not rows:
        print("No data")
        return
    
    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(str(cell)))
    
    # Print header
    header_line = " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    print(header_line)
    print("-" * len(header_line))
    
    # Print rows
    for row in rows:
        print(" | ".join(str(cell).ljust(widths[i]) for i, cell in enumerate(row)))


async def cmd_search(args) -> int:
    """Execute memory search command"""
    config = create_default_config(args.agent_id)
    
    # Apply command-line overrides
    if args.provider:
        config.provider = args.provider
    if args.model:
        config.model = args.model
    if args.api_key:
        config.api_key = args.api_key
    if args.max_results:
        config.query.max_results = args.max_results
    if args.min_score:
        config.query.min_score = args.min_score
    
    # Load from environment if available
    env_config = load_config_from_env()
    if env_config.api_key and not config.api_key:
        config.api_key = env_config.api_key
    
    # Convert to manager config
    manager_config = ManagerConfig(
        enabled=config.enabled,
        sources=config.sources,
        extra_paths=config.extra_paths,
        provider=config.provider,
        model=config.model,
        fallback=config.fallback,
        api_key=config.api_key,
        base_url=config.base_url,
        dimensions=config.output_dimensionality,
        local_model_path=config.local.model_path,
        local_model_cache_dir=config.local.model_cache_dir,
        store=config.store,
        chunking=config.chunking,
        sync=config.sync,
        query=config.query,
        cache=config.cache,
    )
    
    try:
        result = await memory_search(
            query=args.query,
            agent_id=args.agent_id,
            workspace_dir=args.workspace or os.getcwd(),
            config=manager_config,
            max_results=args.max_results,
            min_score=args.min_score,
        )
        
        if args.json:
            print_json({
                "results": [
                    {
                        "path": r.path,
                        "start_line": r.start_line,
                        "end_line": r.end_line,
                        "score": r.score,
                        "snippet": r.snippet,
                        "source": r.source.value,
                    }
                    for r in result.results
                ],
                "provider": result.provider,
                "model": result.model,
                "mode": result.mode,
            })
        else:
            if not result.results:
                print("No relevant memories found.")
                return 0
            
            print(f"Found {len(result.results)} memories (provider: {result.provider}, mode: {result.mode}):\n")
            for i, r in enumerate(result.results, 1):
                print(f"[{i}] {r.path}#L{r.start_line}-L{r.end_line} (score: {r.score:.3f})")
                print(f"    {r.snippet[:200]}{'...' if len(r.snippet) > 200 else ''}")
                print()
        
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


async def cmd_get(args) -> int:
    """Execute memory get command"""
    config = create_default_config(args.agent_id)
    
    manager_config = ManagerConfig(
        enabled=config.enabled,
        sources=config.sources,
        extra_paths=config.extra_paths,
        provider=config.provider,
        model=config.model,
        fallback=config.fallback,
        api_key=config.api_key,
        base_url=config.base_url,
        dimensions=config.output_dimensionality,
        local_model_path=config.local.model_path,
        local_model_cache_dir=config.local.model_cache_dir,
        store=config.store,
        chunking=config.chunking,
        sync=config.sync,
        query=config.query,
        cache=config.cache,
    )
    
    try:
        result = await memory_get(
            path=args.path,
            agent_id=args.agent_id,
            workspace_dir=args.workspace or os.getcwd(),
            config=manager_config,
            from_line=args.from_line,
            lines=args.lines,
        )
        
        if args.json:
            print_json({
                "text": result.text,
                "path": result.path,
                "error": result.error,
            })
        else:
            if result.error:
                print(f"Error: {result.error}", file=sys.stderr)
                return 1
            if not result.text:
                print(f"(empty file: {result.path})")
            else:
                print(result.text)
        
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


async def cmd_sync(args) -> int:
    """Execute memory sync command"""
    config = create_default_config(args.agent_id)
    
    manager_config = ManagerConfig(
        enabled=config.enabled,
        sources=config.sources,
        extra_paths=config.extra_paths,
        provider=config.provider,
        model=config.model,
        fallback=config.fallback,
        api_key=config.api_key,
        base_url=config.base_url,
        dimensions=config.output_dimensionality,
        local_model_path=config.local.model_path,
        local_model_cache_dir=config.local.model_cache_dir,
        store=config.store,
        chunking=config.chunking,
        sync=config.sync,
        query=config.query,
        cache=config.cache,
    )
    
    try:
        manager = await MemoryIndexManager.get(
            agent_id=args.agent_id,
            workspace_dir=args.workspace or os.getcwd(),
            config=manager_config,
        )
        
        if not manager:
            print("Failed to initialize memory manager", file=sys.stderr)
            return 1
        
        def progress_callback(update):
            if not args.quiet:
                print(f"\r{update.get('label', 'Syncing')} ({update['completed']}/{update['total']})", end="")
        
        await manager.sync(
            reason="manual",
            force=args.force,
            progress=progress_callback if not args.quiet else None,
        )
        
        if not args.quiet:
            print("\nSync complete.")
            status = manager.status()
            print(f"Files: {status.files}, Chunks: {status.chunks}")
        
        await manager.close()
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


async def cmd_status(args) -> int:
    """Execute memory status command"""
    config = create_default_config(args.agent_id)
    
    manager_config = ManagerConfig(
        enabled=config.enabled,
        sources=config.sources,
        extra_paths=config.extra_paths,
        provider=config.provider,
        model=config.model,
        fallback=config.fallback,
        api_key=config.api_key,
        base_url=config.base_url,
        dimensions=config.output_dimensionality,
        local_model_path=config.local.model_path,
        local_model_cache_dir=config.local.model_cache_dir,
        store=config.store,
        chunking=config.chunking,
        sync=config.sync,
        query=config.query,
        cache=config.cache,
    )
    
    try:
        manager = await MemoryIndexManager.get(
            agent_id=args.agent_id,
            workspace_dir=args.workspace or os.getcwd(),
            config=manager_config,
        )
        
        if not manager:
            print("Failed to initialize memory manager", file=sys.stderr)
            return 1
        
        status = manager.status()
        
        if args.json:
            print_json({
                "backend": status.backend,
                "provider": status.provider,
                "model": status.model,
                "files": status.files,
                "chunks": status.chunks,
                "dirty": status.dirty,
                "workspace_dir": status.workspace_dir,
                "db_path": status.db_path,
                "sources": [s.value for s in status.sources] if status.sources else [],
                "cache": status.cache,
                "fts": status.fts,
                "vector": status.vector,
            })
        else:
            print(f"Memory Status (Agent: {args.agent_id})")
            print("=" * 50)
            print(f"Backend:  {status.backend}")
            print(f"Provider: {status.provider}")
            print(f"Model:    {status.model or 'N/A'}")
            print(f"Files:    {status.files}")
            print(f"Chunks:   {status.chunks}")
            print(f"Dirty:    {status.dirty}")
            print(f"DB Path:  {status.db_path}")
            
            if status.sources:
                print(f"\nSources:")
                for source in status.sources:
                    print(f"  - {source.value}")
            
            if status.cache and status.cache.get("enabled"):
                print(f"\nCache: {status.cache.get('entries', 0)}/{status.cache.get('max_entries', 'inf')} entries")
            
            if status.vector:
                print(f"\nVector: enabled={status.vector.get('enabled')}, available={status.vector.get('available')}")
                if status.vector.get("dims"):
                    print(f"  Dimensions: {status.vector['dims']}")
            
            if status.fts:
                print(f"FTS:    enabled={status.fts.get('enabled')}, available={status.fts.get('available')}")
        
        await manager.close()
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


async def cmd_lancedb(args) -> int:
    """LanceDB memory commands"""
    if args.lancedb_command == "store":
        return await lancedb_store(args)
    elif args.lancedb_command == "search":
        return await lancedb_search(args)
    elif args.lancedb_command == "forget":
        return await lancedb_forget(args)
    elif args.lancedb_command == "stats":
        return await lancedb_stats(args)
    else:
        print(f"Unknown lancedb command: {args.lancedb_command}", file=sys.stderr)
        return 1


async def lancedb_store(args) -> int:
    """Store a memory in LanceDB"""
    try:
        memory = await create_lancedb_memory(
            db_path=args.db_path,
            openai_api_key=args.api_key,
            openai_base_url=args.base_url,
            embedding_model=args.model,
        )
        
        from memory_lancedb import MemoryCategory
        
        category = None
        if args.category:
            category = MemoryCategory(args.category)
        
        entry = await memory.store(
            text=args.text,
            importance=args.importance or 0.7,
            category=category,
        )
        
        if args.json:
            print_json({
                "id": entry.id,
                "text": entry.text,
                "category": entry.category.value,
                "importance": entry.importance,
            })
        else:
            print(f"Stored memory: {entry.id}")
            print(f"  Category: {entry.category.value}")
            print(f"  Text: {entry.text[:100]}...")
        
        await memory.close()
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


async def lancedb_search(args) -> int:
    """Search memories in LanceDB"""
    try:
        memory = await create_lancedb_memory(
            db_path=args.db_path,
            openai_api_key=args.api_key,
            openai_base_url=args.base_url,
            embedding_model=args.model,
        )
        
        results = await memory.search(
            query=args.query,
            limit=args.limit or 5,
            min_score=args.min_score or 0.3,
        )
        
        if args.json:
            print_json({
                "results": [
                    {
                        "id": r.entry.id,
                        "text": r.entry.text,
                        "category": r.entry.category.value,
                        "score": r.score,
                    }
                    for r in results
                ]
            })
        else:
            if not results:
                print("No relevant memories found.")
                return 0
            
            print(f"Found {len(results)} memories:\n")
            for i, r in enumerate(results, 1):
                print(f"[{i}] [{r.entry.category.value}] (score: {r.score:.3f})")
                print(f"    {r.entry.text}")
                print()
        
        await memory.close()
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


async def lancedb_forget(args) -> int:
    """Delete memories from LanceDB"""
    try:
        memory = await create_lancedb_memory(
            db_path=args.db_path,
            openai_api_key=args.api_key,
            openai_base_url=args.base_url,
            embedding_model=args.model,
        )
        
        result = await memory.forget(
            memory_id=args.id,
            query=args.query,
        )
        
        if args.json:
            print_json(result)
        else:
            if result.get("action") == "deleted":
                print(f"Deleted memory: {result['id']}")
            elif result.get("action") == "candidates":
                print("Multiple candidates found. Specify memory ID:")
                for c in result.get("candidates", []):
                    print(f"  {c['id'][:8]}... (score: {c['score']:.3f}) - {c['text'][:50]}...")
            else:
                print(f"No matching memories found.")
        
        await memory.close()
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


async def lancedb_stats(args) -> int:
    """Show LanceDB memory statistics"""
    try:
        memory = await create_lancedb_memory(
            db_path=args.db_path,
            openai_api_key=args.api_key,
            openai_base_url=args.base_url,
            embedding_model=args.model,
        )
        
        stats = await memory.stats()
        
        if args.json:
            print_json(stats)
        else:
            print("LanceDB Memory Statistics")
            print("=" * 30)
            print(f"Total memories: {stats['total']}")
            if stats['by_category']:
                print("\nBy category:")
                for cat, count in stats['by_category'].items():
                    print(f"  {cat}: {count}")
        
        await memory.close()
        return 0
        
    except Exception as e:
        if args.json:
            print_json({"error": str(e)})
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


def main() -> int:
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="OpenClaw Memory System - Python Implementation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search memories")
    search_parser.add_argument("query", help="Search query")
    search_parser.add_argument("--agent-id", "-a", required=True, help="Agent ID")
    search_parser.add_argument("--workspace", "-w", help="Workspace directory")
    search_parser.add_argument("--provider", "-p", help="Embedding provider")
    search_parser.add_argument("--model", "-m", help="Embedding model")
    search_parser.add_argument("--api-key", "-k", help="API key")
    search_parser.add_argument("--max-results", "-n", type=int, help="Max results")
    search_parser.add_argument("--min-score", "-s", type=float, help="Min score threshold")
    search_parser.add_argument("--json", "-j", action="store_true", help="JSON output")
    search_parser.set_defaults(func=cmd_search)
    
    # Get command
    get_parser = subparsers.add_parser("get", help="Get memory file snippet")
    get_parser.add_argument("path", help="File path")
    get_parser.add_argument("--agent-id", "-a", required=True, help="Agent ID")
    get_parser.add_argument("--workspace", "-w", help="Workspace directory")
    get_parser.add_argument("--from-line", "-f", type=int, help="Start line")
    get_parser.add_argument("--lines", "-l", type=int, help="Number of lines")
    get_parser.add_argument("--json", "-j", action="store_true", help="JSON output")
    get_parser.set_defaults(func=cmd_get)
    
    # Sync command
    sync_parser = subparsers.add_parser("sync", help="Sync memory index")
    sync_parser.add_argument("--agent-id", "-a", required=True, help="Agent ID")
    sync_parser.add_argument("--workspace", "-w", help="Workspace directory")
    sync_parser.add_argument("--force", "-F", action="store_true", help="Force sync")
    sync_parser.add_argument("--quiet", "-q", action="store_true", help="Quiet mode")
    sync_parser.add_argument("--json", "-j", action="store_true", help="JSON output")
    sync_parser.set_defaults(func=cmd_sync)
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Show memory status")
    status_parser.add_argument("--agent-id", "-a", required=True, help="Agent ID")
    status_parser.add_argument("--workspace", "-w", help="Workspace directory")
    status_parser.add_argument("--json", "-j", action="store_true", help="JSON output")
    status_parser.set_defaults(func=cmd_status)
    
    # LanceDB commands
    lancedb_parser = subparsers.add_parser("ltm", help="LanceDB memory commands")
    lancedb_subparsers = lancedb_parser.add_subparsers(dest="lancedb_command")
    
    # ltm store
    ltm_store = lancedb_subparsers.add_parser("store", help="Store a memory")
    ltm_store.add_argument("text", help="Text to remember")
    ltm_store.add_argument("--db-path", default="~/.openclaw/memory-lancedb")
    ltm_store.add_argument("--api-key", "-k")
    ltm_store.add_argument("--base-url")
    ltm_store.add_argument("--model", "-m", default="text-embedding-3-small")
    ltm_store.add_argument("--importance", "-i", type=float)
    ltm_store.add_argument("--category", "-c", choices=["preference", "decision", "entity", "fact", "other"])
    ltm_store.add_argument("--json", "-j", action="store_true")
    
    # ltm search
    ltm_search = lancedb_subparsers.add_parser("search", help="Search memories")
    ltm_search.add_argument("query", help="Search query")
    ltm_search.add_argument("--db-path", default="~/.openclaw/memory-lancedb")
    ltm_search.add_argument("--api-key", "-k")
    ltm_search.add_argument("--base-url")
    ltm_search.add_argument("--model", "-m", default="text-embedding-3-small")
    ltm_search.add_argument("--limit", "-n", type=int, default=5)
    ltm_search.add_argument("--min-score", "-s", type=float, default=0.3)
    ltm_search.add_argument("--json", "-j", action="store_true")
    
    # ltm forget
    ltm_forget = lancedb_subparsers.add_parser("forget", help="Delete memories")
    ltm_forget.add_argument("--id", help="Memory ID")
    ltm_forget.add_argument("--query", "-q", help="Search query to find memory")
    ltm_forget.add_argument("--db-path", default="~/.openclaw/memory-lancedb")
    ltm_forget.add_argument("--api-key", "-k")
    ltm_forget.add_argument("--base-url")
    ltm_forget.add_argument("--model", "-m", default="text-embedding-3-small")
    ltm_forget.add_argument("--json", "-j", action="store_true")
    
    # ltm stats
    ltm_stats = lancedb_subparsers.add_parser("stats", help="Memory statistics")
    ltm_stats.add_argument("--db-path", default="~/.openclaw/memory-lancedb")
    ltm_stats.add_argument("--api-key", "-k")
    ltm_stats.add_argument("--base-url")
    ltm_stats.add_argument("--model", "-m", default="text-embedding-3-small")
    ltm_stats.add_argument("--json", "-j", action="store_true")
    
    lancedb_parser.set_defaults(func=cmd_lancedb)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    return asyncio.run(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
