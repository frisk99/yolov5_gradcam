"""
OpenClaw Memory System - Python Implementation
Memory tools for searching and retrieving memories
"""

import asyncio
from typing import Optional, Any
from dataclasses import dataclass

# Note: Using local types module, not Python's built-in 'types'
from .memory_types import MemorySearchResult, MemoryCitationsMode  # type: ignore
from .manager import MemoryIndexManager, ResolvedMemoryConfig  # type: ignore


@dataclass
class MemorySearchResponse:
    """Response from memory search"""
    results: list[MemorySearchResult]
    provider: str
    model: Optional[str] = None
    fallback: Optional[dict] = None
    citations: str = "auto"
    mode: str = "hybrid"
    disabled: bool = False
    unavailable: bool = False
    error: Optional[str] = None
    warning: Optional[str] = None
    action: Optional[str] = None


@dataclass
class MemoryGetResponse:
    """Response from memory get"""
    text: str
    path: str
    disabled: bool = False
    error: Optional[str] = None


def format_citation(result: MemorySearchResult) -> str:
    """Format a citation for a search result"""
    if result.start_line == result.end_line:
        return f"{result.path}#L{result.start_line}"
    return f"{result.path}#L{result.start_line}-L{result.end_line}"


def decorate_citations(
    results: list[MemorySearchResult],
    include_citations: bool,
) -> list[MemorySearchResult]:
    """Add citations to search results"""
    decorated = []
    for result in results:
        if include_citations:
            citation = format_citation(result)
            snippet = f"{result.snippet.strip()}\n\nSource: {citation}"
            decorated.append(MemorySearchResult(
                path=result.path,
                start_line=result.start_line,
                end_line=result.end_line,
                score=result.score,
                snippet=snippet,
                source=result.source,
                citation=citation,
            ))
        else:
            decorated.append(MemorySearchResult(
                path=result.path,
                start_line=result.start_line,
                end_line=result.end_line,
                score=result.score,
                snippet=result.snippet,
                source=result.source,
                citation=None,
            ))
    return decorated


def clamp_results_by_chars(
    results: list[MemorySearchResult],
    budget: Optional[int],
) -> list[MemorySearchResult]:
    """Clamp results to fit within character budget"""
    if not budget or budget <= 0:
        return results
    
    remaining = budget
    clamped = []
    
    for result in results:
        if remaining <= 0:
            break
        
        snippet = result.snippet or ""
        if len(snippet) <= remaining:
            clamped.append(result)
            remaining -= len(snippet)
        else:
            # Trim the snippet
            trimmed = snippet[:remaining]
            clamped.append(MemorySearchResult(
                path=result.path,
                start_line=result.start_line,
                end_line=result.end_line,
                score=result.score,
                snippet=trimmed,
                source=result.source,
                citation=result.citation,
            ))
            break
    
    return clamped


def derive_chat_type_from_session_key(session_key: Optional[str]) -> str:
    """Derive chat type from session key"""
    if not session_key:
        return "direct"
    
    tokens = set(session_key.lower().split(":"))
    if "channel" in tokens:
        return "channel"
    if "group" in tokens:
        return "group"
    return "direct"


def should_include_citations(
    mode: MemoryCitationsMode,
    session_key: Optional[str] = None,
) -> bool:
    """Determine if citations should be included"""
    if mode == MemoryCitationsMode.ON:
        return True
    if mode == MemoryCitationsMode.OFF:
        return False
    
    # Auto mode: show in direct chats, suppress in groups/channels
    chat_type = derive_chat_type_from_session_key(session_key)
    return chat_type == "direct"


def build_memory_search_unavailable_result(error: str) -> MemorySearchResponse:
    """Build error response for unavailable memory search"""
    reason = error.strip() or "memory search unavailable"
    is_quota_error = any(kw in reason.lower() for kw in ["insufficient_quota", "quota", "429"])
    
    warning = (
        "Memory search is unavailable because the embedding provider quota is exhausted."
        if is_quota_error
        else "Memory search is unavailable due to an embedding/provider error."
    )
    
    action = (
        "Top up or switch embedding provider, then retry memory_search."
        if is_quota_error
        else "Check embedding provider configuration and retry memory_search."
    )
    
    return MemorySearchResponse(
        results=[],
        disabled=True,
        unavailable=True,
        error=reason,
        warning=warning,
        action=action,
        provider="none",
    )


class MemorySearchTool:
    """
    Memory search tool for semantic search.
    
    Usage:
        tool = MemorySearchTool(manager, config)
        result = await tool.execute(query="user preferences", max_results=5)
    """
    
    def __init__(
        self,
        manager: MemoryIndexManager,
        config: ResolvedMemoryConfig,
        session_key: Optional[str] = None,
    ):
        self.manager = manager
        self.config = config
        self.session_key = session_key
        self.citations_mode = MemoryCitationsMode.AUTO
    
    async def execute(
        self,
        query: str,
        max_results: Optional[int] = None,
        min_score: Optional[float] = None,
    ) -> MemorySearchResponse:
        """Execute memory search"""
        try:
            # Check if manager is available
            status = self.manager.status()
            
            # Get citations mode
            include_citations = should_include_citations(
                self.citations_mode,
                self.session_key,
            )
            
            # Perform search
            raw_results = await self.manager.search(
                query=query,
                max_results=max_results,
                min_score=min_score,
                session_key=self.session_key,
            )
            
            # Decorate with citations
            decorated = decorate_citations(raw_results, include_citations)
            
            # Clamp by character budget if using QMD backend
            results = decorated
            if status.backend == "qmd":
                max_injected_chars = getattr(self.config, "max_injected_chars", 10000)
                results = clamp_results_by_chars(decorated, max_injected_chars)
            
            # Determine search mode
            search_mode = status.custom.get("searchMode", "hybrid") if status.custom else "hybrid"
            
            return MemorySearchResponse(
                results=results,
                provider=status.provider,
                model=status.model,
                fallback=status.fallback,
                citations=self.citations_mode.value,
                mode=search_mode,
            )
            
        except Exception as e:
            return build_memory_search_unavailable_result(str(e))


class MemoryGetTool:
    """
    Memory get tool for reading specific file snippets.
    
    Usage:
        tool = MemoryGetTool(manager)
        result = await tool.execute(path="memory/preferences.md", from_line=10, lines=20)
    """
    
    def __init__(
        self,
        manager: MemoryIndexManager,
    ):
        self.manager = manager
    
    async def execute(
        self,
        path: str,
        from_line: Optional[int] = None,
        lines: Optional[int] = None,
    ) -> MemoryGetResponse:
        """Execute memory get"""
        result = await self.manager.read_file(
            rel_path=path,
            from_line=from_line,
            lines=lines,
        )
        
        return MemoryGetResponse(
            text=result.get("text", ""),
            path=result.get("path", path),
            disabled=result.get("disabled", False),
            error=result.get("error"),
        )


class MemoryToolFactory:
    """Factory for creating memory tools"""
    
    def __init__(
        self,
        manager: MemoryIndexManager,
        config: ResolvedMemoryConfig,
    ):
        self.manager = manager
        self.config = config
    
    def create_search_tool(
        self,
        session_key: Optional[str] = None,
    ) -> MemorySearchTool:
        """Create a memory search tool"""
        return MemorySearchTool(
            manager=self.manager,
            config=self.config,
            session_key=session_key,
        )
    
    def create_get_tool(self) -> MemoryGetTool:
        """Create a memory get tool"""
        return MemoryGetTool(manager=self.manager)


async def create_memory_tools(
    agent_id: str,
    workspace_dir: str,
    config: ResolvedMemoryConfig,
    session_key: Optional[str] = None,
) -> tuple[MemorySearchTool, MemoryGetTool]:
    """
    Create memory tools for an agent.
    
    Args:
        agent_id: Agent identifier
        workspace_dir: Agent workspace directory
        config: Memory configuration
        session_key: Optional session key for citations
    
    Returns:
        Tuple of (MemorySearchTool, MemoryGetTool)
    """
    manager = await MemoryIndexManager.get(
        agent_id=agent_id,
        workspace_dir=workspace_dir,
        config=config,
    )
    
    if not manager:
        raise ValueError("Failed to create MemoryIndexManager")
    
    factory = MemoryToolFactory(manager, config)
    search_tool = factory.create_search_tool(session_key)
    get_tool = factory.create_get_tool()
    
    return search_tool, get_tool


# CLI-style interface for memory operations
async def memory_search(
    query: str,
    agent_id: str,
    workspace_dir: str,
    config: ResolvedMemoryConfig,
    max_results: Optional[int] = None,
    min_score: Optional[float] = None,
    session_key: Optional[str] = None,
) -> MemorySearchResponse:
    """
    Perform a memory search.
    
    Args:
        query: Search query
        agent_id: Agent identifier
        workspace_dir: Agent workspace directory
        config: Memory configuration
        max_results: Maximum results to return
        min_score: Minimum score threshold
        session_key: Optional session key
    
    Returns:
        MemorySearchResponse with results
    """
    manager = await MemoryIndexManager.get(
        agent_id=agent_id,
        workspace_dir=workspace_dir,
        config=config,
    )
    
    if not manager:
        return build_memory_search_unavailable_result("Failed to initialize memory manager")
    
    tool = MemorySearchTool(manager, config, session_key)
    return await tool.execute(query, max_results, min_score)


async def memory_get(
    path: str,
    agent_id: str,
    workspace_dir: str,
    config: ResolvedMemoryConfig,
    from_line: Optional[int] = None,
    lines: Optional[int] = None,
) -> MemoryGetResponse:
    """
    Get a memory file snippet.
    
    Args:
        path: Relative path to memory file
        agent_id: Agent identifier
        workspace_dir: Agent workspace directory
        config: Memory configuration
        from_line: Starting line number
        lines: Number of lines to return
    
    Returns:
        MemoryGetResponse with text content
    """
    manager = await MemoryIndexManager.get(
        agent_id=agent_id,
        workspace_dir=workspace_dir,
        config=config,
    )
    
    if not manager:
        return MemoryGetResponse(
            text="",
            path=path,
            disabled=True,
            error="Failed to initialize memory manager",
        )
    
    tool = MemoryGetTool(manager)
    return await tool.execute(path, from_line, lines)
