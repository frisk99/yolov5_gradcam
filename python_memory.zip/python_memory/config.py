"""
OpenClaw Memory System - Python Implementation
Configuration module
"""

import os
from dataclasses import dataclass, field
from typing import Optional, Any
from pathlib import Path

# Note: Using local types module, not Python's built-in 'types'
try:
    from .memory_types import MemorySource  # type: ignore
except ImportError:
    from memory_types import MemorySource  # type: ignore


@dataclass
class MemoryMultimodalConfig:
    """Multimodal memory configuration"""
    enabled: bool = False
    modalities: list[str] = field(default_factory=lambda: ["image"])
    max_file_bytes: int = 10 * 1024 * 1024  # 10MB


@dataclass
class MemoryRemoteConfig:
    """Remote embedding configuration"""
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    headers: dict[str, str] = field(default_factory=dict)
    batch: dict[str, Any] = field(default_factory=lambda: {
        "enabled": False,
        "wait": True,
        "concurrency": 2,
        "poll_interval_ms": 2000,
        "timeout_minutes": 60,
    })


@dataclass
class MemoryLocalConfig:
    """Local embedding configuration"""
    model_path: Optional[str] = None
    model_cache_dir: Optional[str] = None


@dataclass
class MemoryVectorConfig:
    """Vector storage configuration"""
    enabled: bool = True
    extension_path: Optional[str] = None


@dataclass
class MemoryStoreConfig:
    """Storage configuration"""
    driver: str = "sqlite"
    path: Optional[str] = None
    vector: MemoryVectorConfig = field(default_factory=MemoryVectorConfig)


@dataclass
class MemoryChunkingConfig:
    """Text chunking configuration"""
    tokens: int = 400
    overlap: int = 80


@dataclass
class MemorySessionsSyncConfig:
    """Session sync configuration"""
    delta_bytes: int = 100_000
    delta_messages: int = 50
    post_compaction_force: bool = True


@dataclass
class MemorySyncConfig:
    """Sync configuration"""
    on_session_start: bool = True
    on_search: bool = True
    watch: bool = True
    watch_debounce_ms: int = 1500
    interval_minutes: int = 0
    sessions: MemorySessionsSyncConfig = field(default_factory=MemorySessionsSyncConfig)


@dataclass
class MemoryMmrConfig:
    """MMR (Maximal Marginal Relevance) configuration"""
    enabled: bool = False
    lambda_param: float = 0.7


@dataclass
class MemoryTemporalDecayConfig:
    """Temporal decay configuration"""
    enabled: bool = False
    half_life_days: int = 30


@dataclass
class MemoryHybridConfig:
    """Hybrid search configuration"""
    enabled: bool = True
    vector_weight: float = 0.7
    text_weight: float = 0.3
    candidate_multiplier: float = 4.0
    mmr: MemoryMmrConfig = field(default_factory=MemoryMmrConfig)
    temporal_decay: MemoryTemporalDecayConfig = field(default_factory=MemoryTemporalDecayConfig)


@dataclass
class MemoryQueryConfig:
    """Query configuration"""
    max_results: int = 6
    min_score: float = 0.35
    hybrid: MemoryHybridConfig = field(default_factory=MemoryHybridConfig)


@dataclass
class MemoryCacheConfig:
    """Embedding cache configuration"""
    enabled: bool = True
    max_entries: Optional[int] = None


@dataclass
class MemoryExperimentalConfig:
    """Experimental features configuration"""
    session_memory: bool = False


@dataclass
class MemoryConfig:
    """
    Memory configuration for OpenClaw Python implementation.
    
    This configuration can be loaded from YAML/JSON or environment variables.
    
    Example YAML:
        memory:
          enabled: true
          provider: "openai"
          model: "text-embedding-3-small"
          fallback: "local"
          sources:
            - "memory"
            - "sessions"
          store:
            path: "~/.openclaw/memory/{agent_id}.sqlite"
            vector:
              enabled: true
          chunking:
            tokens: 400
            overlap: 80
          query:
            max_results: 6
            min_score: 0.35
            hybrid:
              enabled: true
              vector_weight: 0.7
              text_weight: 0.3
    """
    enabled: bool = True
    sources: list[MemorySource] = field(default_factory=lambda: [MemorySource.MEMORY])
    extra_paths: list[str] = field(default_factory=list)
    multimodal: MemoryMultimodalConfig = field(default_factory=MemoryMultimodalConfig)
    provider: str = "auto"
    remote: Optional[MemoryRemoteConfig] = None
    experimental: MemoryExperimentalConfig = field(default_factory=MemoryExperimentalConfig)
    fallback: str = "none"
    model: str = ""
    output_dimensionality: Optional[int] = None
    local: MemoryLocalConfig = field(default_factory=MemoryLocalConfig)
    store: MemoryStoreConfig = field(default_factory=MemoryStoreConfig)
    chunking: MemoryChunkingConfig = field(default_factory=MemoryChunkingConfig)
    sync: MemorySyncConfig = field(default_factory=MemorySyncConfig)
    query: MemoryQueryConfig = field(default_factory=MemoryQueryConfig)
    cache: MemoryCacheConfig = field(default_factory=MemoryCacheConfig)
    
    # Runtime fields (not serialized)
    api_key: Optional[str] = None
    base_url: Optional[str] = None


def resolve_store_path(agent_id: str, raw_path: Optional[str]) -> str:
    """
    Resolve memory store path with token substitution.
    
    Args:
        agent_id: Agent identifier
        raw_path: Raw path with optional {agentId} token
    
    Returns:
        Resolved absolute path
    """
    state_dir = os.path.expanduser("~/.openclaw/state")
    default_path = os.path.join(state_dir, "memory", f"{agent_id}.sqlite")
    
    if not raw_path:
        return default_path
    
    # Substitute tokens
    path = raw_path.replace("{agentId}", agent_id)
    path = path.replace("{agent_id}", agent_id)
    
    # Expand user and environment variables
    path = os.path.expanduser(path)
    path = os.path.expandvars(path)
    
    # Resolve relative paths
    if not os.path.isabs(path):
        path = os.path.abspath(path)
    
    return path


def resolve_user_path(path: str) -> str:
    """Resolve user path with ~ and environment variables"""
    path = os.path.expanduser(path)
    path = os.path.expandvars(path)
    return path


def load_config_from_env() -> MemoryConfig:
    """Load memory configuration from environment variables"""
    config = MemoryConfig()
    
    # Provider settings
    if os.environ.get("MEMORY_PROVIDER"):
        config.provider = os.environ["MEMORY_PROVIDER"]
    if os.environ.get("MEMORY_MODEL"):
        config.model = os.environ["MEMORY_MODEL"]
    if os.environ.get("MEMORY_FALLBACK"):
        config.fallback = os.environ["MEMORY_FALLBACK"]
    
    # API settings
    if os.environ.get("MEMORY_API_KEY"):
        config.api_key = os.environ["MEMORY_API_KEY"]
    if os.environ.get("MEMORY_BASE_URL"):
        config.base_url = os.environ["MEMORY_BASE_URL"]
    if os.environ.get("MEMORY_OPENAI_API_KEY"):
        config.api_key = os.environ["MEMORY_OPENAI_API_KEY"]
    if os.environ.get("OPENAI_API_KEY") and not config.api_key:
        config.api_key = os.environ["OPENAI_API_KEY"]
    if os.environ.get("OPENAI_BASE_URL"):
        config.base_url = os.environ["OPENAI_BASE_URL"]
    
    # Store settings
    if os.environ.get("MEMORY_STORE_PATH"):
        config.store.path = os.environ["MEMORY_STORE_PATH"]
    if os.environ.get("MEMORY_VECTOR_ENABLED"):
        config.store.vector.enabled = os.environ["MEMORY_VECTOR_ENABLED"].lower() == "true"
    
    # Query settings
    if os.environ.get("MEMORY_MAX_RESULTS"):
        config.query.max_results = int(os.environ["MEMORY_MAX_RESULTS"])
    if os.environ.get("MEMORY_MIN_SCORE"):
        config.query.min_score = float(os.environ["MEMORY_MIN_SCORE"])
    
    # Chunking settings
    if os.environ.get("MEMORY_CHUNK_TOKENS"):
        config.chunking.tokens = int(os.environ["MEMORY_CHUNK_TOKENS"])
    if os.environ.get("MEMORY_CHUNK_OVERLAP"):
        config.chunking.overlap = int(os.environ["MEMORY_CHUNK_OVERLAP"])
    
    # Cache settings
    if os.environ.get("MEMORY_CACHE_ENABLED"):
        config.cache.enabled = os.environ["MEMORY_CACHE_ENABLED"].lower() == "true"
    if os.environ.get("MEMORY_CACHE_MAX_ENTRIES"):
        config.cache.max_entries = int(os.environ["MEMORY_CACHE_MAX_ENTRIES"])
    
    return config


def load_config_from_dict(data: dict) -> MemoryConfig:
    """Load memory configuration from dictionary"""
    config = MemoryConfig()
    
    if "enabled" in data:
        config.enabled = bool(data["enabled"])
    if "sources" in data:
        config.sources = [MemorySource(s) for s in data["sources"]]
    if "extra_paths" in data:
        config.extra_paths = list(data["extra_paths"])
    if "provider" in data:
        config.provider = str(data["provider"])
    if "model" in data:
        config.model = str(data["model"])
    if "fallback" in data:
        config.fallback = str(data["fallback"])
    if "api_key" in data:
        config.api_key = str(data["api_key"])
    if "base_url" in data:
        config.base_url = str(data["base_url"])
    if "output_dimensionality" in data:
        config.output_dimensionality = int(data["output_dimensionality"])
    
    # Nested configs
    if "multimodal" in data:
        mm = data["multimodal"]
        if "enabled" in mm:
            config.multimodal.enabled = bool(mm["enabled"])
        if "modalities" in mm:
            config.multimodal.modalities = list(mm["modalities"])
        if "max_file_bytes" in mm:
            config.multimodal.max_file_bytes = int(mm["max_file_bytes"])
    
    if "remote" in data:
        r = data["remote"]
        config.remote = MemoryRemoteConfig(
            base_url=r.get("base_url"),
            api_key=r.get("api_key"),
            headers=r.get("headers", {}),
            batch=r.get("batch", {}),
        )
    
    if "local" in data:
        l = data["local"]
        config.local = MemoryLocalConfig(
            model_path=l.get("model_path"),
            model_cache_dir=l.get("model_cache_dir"),
        )
    
    if "store" in data:
        s = data["store"]
        if "driver" in s:
            config.store.driver = str(s["driver"])
        if "path" in s:
            config.store.path = str(s["path"])
        if "vector" in s:
            v = s["vector"]
            if "enabled" in v:
                config.store.vector.enabled = bool(v["enabled"])
            if "extension_path" in v:
                config.store.vector.extension_path = str(v["extension_path"])
    
    if "chunking" in data:
        c = data["chunking"]
        if "tokens" in c:
            config.chunking.tokens = int(c["tokens"])
        if "overlap" in c:
            config.chunking.overlap = int(c["overlap"])
    
    if "sync" in data:
        sync = data["sync"]
        if "on_session_start" in sync:
            config.sync.on_session_start = bool(sync["on_session_start"])
        if "on_search" in sync:
            config.sync.on_search = bool(sync["on_search"])
        if "watch" in sync:
            config.sync.watch = bool(sync["watch"])
        if "watch_debounce_ms" in sync:
            config.sync.watch_debounce_ms = int(sync["watch_debounce_ms"])
        if "interval_minutes" in sync:
            config.sync.interval_minutes = int(sync["interval_minutes"])
    
    if "query" in data:
        q = data["query"]
        if "max_results" in q:
            config.query.max_results = int(q["max_results"])
        if "min_score" in q:
            config.query.min_score = float(q["min_score"])
        if "hybrid" in q:
            h = q["hybrid"]
            if "enabled" in h:
                config.query.hybrid.enabled = bool(h["enabled"])
            if "vector_weight" in h:
                config.query.hybrid.vector_weight = float(h["vector_weight"])
            if "text_weight" in h:
                config.query.hybrid.text_weight = float(h["text_weight"])
            if "candidate_multiplier" in h:
                config.query.hybrid.candidate_multiplier = float(h["candidate_multiplier"])
            if "mmr" in h:
                mmr = h["mmr"]
                if "enabled" in mmr:
                    config.query.hybrid.mmr.enabled = bool(mmr["enabled"])
                if "lambda" in mmr:
                    config.query.hybrid.mmr.lambda_param = float(mmr["lambda"])
    
    if "cache" in data:
        c = data["cache"]
        if "enabled" in c:
            config.cache.enabled = bool(c["enabled"])
        if "max_entries" in c:
            config.cache.max_entries = int(c["max_entries"])
    
    return config


def create_default_config(agent_id: str) -> MemoryConfig:
    """Create default memory configuration for an agent"""
    config = MemoryConfig()
    config.store.path = resolve_store_path(agent_id, "~/.openclaw/state/memory/{agent_id}.sqlite")
    return config
