# OpenClaw Memory System - 调用指南

## 目录

1. [CLI 命令行调用](#1-cli-命令行调用)
2. [Python API 调用](#2-python-api-调用)
3. [LanceDB 长期记忆](#3-lancedb-长期记忆)
4. [数据库结构](#4-数据库结构)
5. [配置选项](#5-配置选项)

---

## 1. CLI 命令行调用

### 基本命令

```bash
# 同步记忆 (将文件索引到数据库)
python -m python_memory sync --agent-id <agent-id> --workspace <workspace-dir>

# 搜索记忆
python -m python_memory search "<query>" --agent-id <agent-id> --workspace <workspace-dir>

# 获取特定文件内容
python -m python_memory get "<path>" --agent-id <agent-id> --workspace <workspace-dir>

# 查看状态
python -m python_memory status --agent-id <agent-id> --workspace <workspace-dir>
```

### 命令示例

```bash
# 设置环境变量 (本地 LLM 服务)
export OPENAI_BASE_URL="http://localhost:11434/v1"
export OPENAI_API_KEY="not-needed"

# 1. 同步记忆
python -m python_memory sync --agent-id test-agent --workspace /path/to/workspace

# 2. 搜索记忆
python -m python_memory search "用户偏好设置" --agent-id test-agent --workspace /path/to/workspace

# 3. 获取文件内容
python -m python_memory get "memory/preferences.md" --agent-id test-agent --workspace /path/to/workspace

# 4. 查看状态
python -m python_memory status --agent-id test-agent --workspace /path/to/workspace
```

### 完整测试脚本

```bash
# 运行测试脚本 (包含所有命令的示例)
cd python_memory
bash test_commands.sh
```

---

## 2. Python API 调用

### 2.1 基本存储和搜索

```python
import asyncio
from python_memory import (
    MemoryIndexManager,
    ResolvedMemoryConfig,
    MemorySource,
)

async def main():
    # 步骤 1: 创建配置
    config = ResolvedMemoryConfig(
        enabled=True,
        sources=[MemorySource.MEMORY],
        provider="openai",
        model="nomic-embed-text",
        api_key="not-needed",
        base_url="http://localhost:11434/v1",  # 本地 LLM 服务
    )
    
    # 步骤 2: 获取管理器
    manager = await MemoryIndexManager.get(
        agent_id="test-agent",
        workspace_dir="/path/to/workspace",
        config=config,
    )
    
    # 步骤 3: 同步记忆
    await manager.sync(reason="manual")
    
    # 步骤 4: 搜索记忆
    results = await manager.search(
        query="用户偏好设置",
        max_results=5,
        min_score=0.3,
    )
    
    for r in results:
        print(f"[{r.score:.3f}] {r.path}#L{r.start_line}")
        print(f"    {r.snippet}")
    
    # 步骤 5: 读取特定文件
    content = await manager.read_file(
        rel_path="memory/preferences.md",
        from_line=1,
        lines=10,
    )
    print(content["text"])
    
    # 步骤 6: 查看状态
    status = manager.status()
    print(f"Files: {status.files}, Chunks: {status.chunks}")
    
    # 步骤 7: 关闭管理器
    await manager.close()

asyncio.run(main())
```

### 2.2 使用工具函数 (简化调用)

```python
import asyncio
from python_memory import memory_search, memory_get

async def main():
    # 搜索记忆
    search_result = await memory_search(
        query="用户偏好",
        agent_id="test-agent",
        workspace_dir="/path/to/workspace",
        max_results=5,
        min_score=0.3,
    )
    print(search_result.results)
    
    # 获取文件内容
    get_result = await memory_get(
        path="memory/preferences.md",
        agent_id="test-agent",
        workspace_dir="/path/to/workspace",
    )
    print(get_result.text)

asyncio.run(main())
```

### 2.3 配置示例

```python
from python_memory import ResolvedMemoryConfig, MemorySource

# 最小配置 (FTS-only 模式，无需嵌入提供者)
config = ResolvedMemoryConfig(
    enabled=True,
    sources=[MemorySource.MEMORY],
)

# 完整配置 (启用向量搜索)
config = ResolvedMemoryConfig(
    enabled=True,
    sources=[MemorySource.MEMORY, MemorySource.SESSIONS],
    provider="openai",
    model="text-embedding-3-small",
    api_key="sk-...",
    base_url="http://localhost:11434/v1",  # 本地服务
    
    # 存储配置
    store=StoreConfig(
        path="~/.openclaw/state/memory/{agent_id}.sqlite",
        vector=VectorConfig(enabled=True),
    ),
    
    # 分块配置
    chunking=ChunkingConfig(
        tokens=400,
        overlap=80,
    ),
    
    # 查询配置
    query=QueryConfig(
        max_results=6,
        min_score=0.35,
        hybrid_enabled=True,
        vector_weight=0.7,
        text_weight=0.3,
    ),
    
    # 缓存配置
    cache=CacheConfig(
        enabled=True,
        max_entries=1000,
    ),
    
    # 同步配置
    sync=SyncConfig(
        on_session_start=True,
        on_search=True,
        watch=True,
        watch_debounce_ms=1500,
    ),
)
```

---

## 3. LanceDB 长期记忆

### 3.1 基本使用

```python
import asyncio
from python_memory.memory_lancedb import LanceDBMemory

async def main():
    # 创建 LanceDB 记忆实例
    memory = await LanceDBMemory.create(
        db_path="/tmp/lancedb",
        api_key="not-needed",
        base_url="http://localhost:11434/v1",
        model="nomic-embed-text",
    )
    
    # 存储记忆
    entry = await memory.store(
        text="用户喜欢深色主题",
        category="preference",  # preference/decision/entity/fact/other
        importance=0.8,
    )
    print(f"Stored: {entry.id}")
    
    # 搜索记忆
    results = await memory.search(
        query="界面设置",
        limit=5,
        min_score=0.3,
    )
    for r in results:
        print(f"[{r.score:.3f}] [{r.entry.category}] {r.entry.text}")
    
    # 删除记忆
    await memory.forget(entry_id=entry.id)
    
    # 查看统计
    stats = await memory.stats()
    print(f"Total memories: {stats.total}")
    
    await memory.close()

asyncio.run(main())
```

### 3.2 CLI 调用 LanceDB

```bash
# 存储记忆
python -m python_memory ltm store "用户喜欢深色模式" \
    --category preference \
    --db-path /tmp/lancedb

# 搜索记忆
python -m python_memory ltm search "界面设置" \
    --db-path /tmp/lancedb

# 删除记忆
python -m python_memory ltm forget --id <entry-id> \
    --db-path /tmp/lancedb

# 查看统计
python -m python_memory ltm stats \
    --db-path /tmp/lancedb
```

### 3.3 记忆分类

| 分类 | 说明 | 触发词示例 |
|------|------|-----------|
| `preference` | 用户偏好 | prefer, like, love, hate, want |
| `decision` | 决定 | decided, will use, choose |
| `entity` | 实体信息 | phone, email, name, address |
| `fact` | 事实 | is, are, has, have, was |
| `other` | 其他 | - |

---

## 4. 数据库结构

### SQLite 数据库文件

**默认路径**: `~/.openclaw/state/memory/{agent_id}.sqlite`

例如：
- Agent ID 为 `test-agent`: `~/.openclaw/state/memory/test-agent.sqlite`
- Agent ID 为 `main`: `~/.openclaw/state/memory/main.sqlite`

**自定义路径**: 通过配置指定

```python
config = ResolvedMemoryConfig(
    store=StoreConfig(
        path="/path/to/custom/memory.sqlite",  # 自定义路径
        vector=VectorConfig(enabled=True),
    ),
)
```

### SQLite 表结构

```sql
-- 文件元数据表
CREATE TABLE files (
    id TEXT PRIMARY KEY,
    path TEXT NOT NULL,
    source TEXT NOT NULL,        -- 'memory' | 'sessions'
    hash TEXT NOT NULL,          -- 文件内容 hash
    size INTEGER NOT NULL,
    mtime REAL NOT NULL,
    model TEXT NOT NULL,         -- 嵌入模型标识
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

-- 文本分块表
CREATE TABLE chunks (
    id TEXT PRIMARY KEY,
    path TEXT NOT NULL,
    start_line INTEGER NOT NULL,
    end_line INTEGER NOT NULL,
    text TEXT NOT NULL,
    source TEXT NOT NULL,
    model TEXT NOT NULL,
    hash TEXT NOT NULL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

-- 向量存储表
CREATE TABLE chunks_vec (
    id TEXT PRIMARY KEY,
    embedding BLOB NOT NULL,     -- Float32Array
    model TEXT NOT NULL,
    FOREIGN KEY (id) REFERENCES chunks(id) ON DELETE CASCADE
);

-- FTS5 全文搜索表
CREATE VIRTUAL TABLE chunks_fts USING fts5(
    path, text, source, model,
    content='chunks',
    content_rowid='rowid'
);

-- 嵌入缓存表
CREATE TABLE embedding_cache (
    hash TEXT PRIMARY KEY,
    embedding BLOB NOT NULL,
    model TEXT NOT NULL,
    created_at REAL NOT NULL
);
```

### LanceDB 表结构

```python
# LanceDB 自动创建以下 schema
{
    "id": str,           # 唯一标识
    "text": str,         # 记忆文本
    "category": str,     # 分类
    "importance": float, # 重要性评分
    "created_at": float, # 创建时间戳
    "updated_at": float, # 更新时间戳
    "vector": vector,    # 自动生成的向量
}
```

---

## 5. 配置选项

### 环境变量

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `OPENAI_BASE_URL` | OpenAI 兼容 API 地址 | `http://localhost:11434/v1` |
| `OPENAI_API_KEY` | API 密钥 | `not-needed` |
| `MEMORY_PROVIDER` | 嵌入提供者 | `auto` |
| `MEMORY_MODEL` | 嵌入模型 | 根据提供者 |
| `MEMORY_STORE_PATH` | SQLite 存储路径 | `~/.openclaw/state/memory/{agent_id}.sqlite` |
| `MEMORY_VECTOR_ENABLED` | 启用向量搜索 | `true` |
| `MEMORY_MAX_RESULTS` | 最大结果数 | `6` |
| `MEMORY_MIN_SCORE` | 最小分数 | `0.35` |

### 配置类层次

```
ResolvedMemoryConfig
├── enabled: bool
├── sources: list[MemorySource]
├── provider: str
├── model: str
├── api_key: str | None
├── base_url: str | None
├── store: StoreConfig
│   ├── path: str
│   └── vector: VectorConfig
│       └── enabled: bool
├── chunking: ChunkingConfig
│   ├── tokens: int
│   └── overlap: int
├── query: QueryConfig
│   ├── max_results: int
│   ├── min_score: float
│   ├── hybrid_enabled: bool
│   ├── vector_weight: float
│   └── text_weight: float
├── cache: CacheConfig
│   ├── enabled: bool
│   └── max_entries: int | None
└── sync: SyncConfig
    ├── on_session_start: bool
    ├── on_search: bool
    ├── watch: bool
    └── interval_minutes: int
```

---

## 6. 调用流程图

```
┌─────────────────────────────────────────────────────────────┐
│ 1. 准备阶段                                                 │
│    - 创建 ResolvedMemoryConfig                              │
│    - 设置 provider/model/api_key/base_url                   │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. 获取管理器                                               │
│    manager = await MemoryIndexManager.get(...)              │
│    - 自动创建/打开 SQLite 数据库                              │
│    - 初始化嵌入提供者                                        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. 存储记忆 (sync)                                          │
│    await manager.sync()                                     │
│    - 扫描 memory/*.md 文件                                   │
│    - 分块 → 嵌入 → 存入 SQLite                               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. 搜索/读取                                                │
│    results = await manager.search(query)                    │
│    content = await manager.read_file(path)                  │
└─────────────────────────────────────────────────────────────┘
```

---

## 7. 快速开始示例

```bash
# 1. 安装依赖
cd python_memory
pip install -r requirements.txt

# 2. 设置环境变量 (使用本地 LLM 服务)
export OPENAI_BASE_URL="http://localhost:11434/v1"
export OPENAI_API_KEY="not-needed"

# 3. 创建工作区
mkdir -p /tmp/test-workspace/memory
cat > /tmp/test-workspace/memory/test.md << 'EOF'
# Test Memory

This is a test memory file.
用户偏好：深色模式
EOF

# 4. 同步
python -m python_memory sync \
    --agent-id test \
    --workspace /tmp/test-workspace

# 5. 搜索
python -m python_memory search "用户偏好" \
    --agent-id test \
    --workspace /tmp/test-workspace

# 6. 查看状态
python -m python_memory status \
    --agent-id test \
    --workspace /tmp/test-workspace
