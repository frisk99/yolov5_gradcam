"""
OpenClaw Memory System - Python Implementation
Core type definitions
"""

from dataclasses import dataclass, field
from typing import Literal, Optional
from enum import Enum


class MemorySource(str, Enum):
    """Memory source types"""
    MEMORY = "memory"
    SESSIONS = "sessions"


class EmbeddingProviderId(str, Enum):
    """Supported embedding provider IDs"""
    OPENAI = "openai"
    LOCAL = "local"
    GEMINI = "gemini"
    VOYAGE = "voyage"
    MISTRAL = "mistral"
    OLLAMA = "ollama"


class MemoryCitationsMode(str, Enum):
    """Citation display modes"""
    ON = "on"
    OFF = "off"
    AUTO = "auto"


@dataclass
class MemorySearchResult:
    """Result from a memory search operation"""
    path: str
    start_line: int
    end_line: int
    score: float
    snippet: str
    source: MemorySource
    citation: Optional[str] = None
    id: Optional[str] = None
    text_score: Optional[float] = None


@dataclass
class MemoryEmbeddingProbeResult:
    """Result from probing embedding availability"""
    ok: bool
    error: Optional[str] = None


@dataclass
class MemorySyncProgressUpdate:
    """Progress update for memory sync operations"""
    completed: int
    total: int
    label: Optional[str] = None


@dataclass
class MemoryProviderStatus:
    """Status information for memory provider"""
    backend: Literal["builtin", "qmd"]
    provider: str
    model: Optional[str] = None
    requested_provider: Optional[str] = None
    files: Optional[int] = None
    chunks: Optional[int] = None
    dirty: Optional[bool] = None
    workspace_dir: Optional[str] = None
    db_path: Optional[str] = None
    extra_paths: Optional[list[str]] = None
    sources: Optional[list[MemorySource]] = None
    source_counts: Optional[list[dict]] = None
    cache: Optional[dict] = None
    fts: Optional[dict] = None
    fallback: Optional[dict] = None
    vector: Optional[dict] = None
    batch: Optional[dict] = None
    custom: Optional[dict] = None


@dataclass
class MemorySourceCount:
    """Count of files/chunks by source"""
    source: MemorySource
    files: int
    chunks: int


@dataclass
class EmbeddingProviderResult:
    """Result from creating an embedding provider"""
    provider: Optional["EmbeddingProvider"]
    requested_provider: str
    fallback_from: Optional[str] = None
    fallback_reason: Optional[str] = None
    provider_unavailable_reason: Optional[str] = None
    openai_client: Optional[object] = None
    gemini_client: Optional[object] = None
    voyage_client: Optional[object] = None
    mistral_client: Optional[object] = None
    ollama_client: Optional[object] = None


class MemorySearchManager:
    """Abstract base class for memory search managers"""
    
    async def search(
        self,
        query: str,
        max_results: Optional[int] = None,
        min_score: Optional[float] = None,
        session_key: Optional[str] = None,
    ) -> list[MemorySearchResult]:
        """Search memory for relevant results"""
        raise NotImplementedError
    
    async def read_file(
        self,
        rel_path: str,
        from_line: Optional[int] = None,
        lines: Optional[int] = None,
    ) -> dict:
        """Read a snippet from a memory file"""
        raise NotImplementedError
    
    def status(self) -> MemoryProviderStatus:
        """Get current status of the memory system"""
        raise NotImplementedError
    
    async def sync(
        self,
        reason: Optional[str] = None,
        force: bool = False,
        session_files: Optional[list[str]] = None,
        progress: Optional[callable] = None,
    ) -> None:
        """Sync memory index with source files"""
        pass
    
    async def probe_embedding_availability(self) -> MemoryEmbeddingProbeResult:
        """Probe embedding provider availability"""
        raise NotImplementedError
    
    async def probe_vector_availability(self) -> bool:
        """Probe vector search availability"""
        raise NotImplementedError
    
    async def close(self) -> None:
        """Close and cleanup resources"""
        pass


# Forward reference for type hints
EmbeddingProvider = None
