#!/usr/bin/env python3
"""
OpenClaw Memory System - Python Implementation
Main entry point for `python -m python_memory` execution
"""

from python_memory.main import main

if __name__ == "__main__":
    import sys
    sys.exit(main())
