"""
OpenClaw Memory System - Python Implementation
Embedding providers for generating vector embeddings
"""

import os
import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, Literal
import numpy as np

# Note: Using local types module, not Python's built-in 'types'
from .memory_types import EmbeddingProviderResult, EmbeddingProviderId  # type: ignore


@dataclass
class EmbeddingProvider:
    """Embedding provider interface"""
    id: str
    model: str
    max_input_tokens: Optional[int] = None
    
    async def embed_query(self, text: str) -> list[float]:
        """Embed a single query text"""
        embeddings = await self.embed_batch([text])
        return embeddings[0] if embeddings else []
    
    @abstractmethod
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts"""
        pass


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """OpenAI embedding provider (supports local LLM services)"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: str = "text-embedding-3-small",
        dimensions: Optional[int] = None,
    ):
        # Default to local LLM service (e.g., Ollama, LocalAI, vLLM, etc.)
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "not-needed")
        self.base_url = base_url or os.environ.get("OPENAI_BASE_URL", "http://localhost:11434/v1")
        self.model = model
        self.dimensions = dimensions
        self._client = None
    
    def _get_client(self):
        if self._client is None:
            from openai import AsyncOpenAI
            self._client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
            )
        return self._client
    
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        client = self._get_client()
        kwargs = {"model": self.model, "input": texts}
        if self.dimensions:
            kwargs["dimensions"] = self.dimensions
        
        response = await client.embeddings.create(**kwargs)
        return [item.embedding for item in response.data]


class GeminiEmbeddingProvider(EmbeddingProvider):
    """Google Gemini embedding provider"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-embedding-001",
        dimensions: Optional[int] = None,
        task_type: Optional[str] = None,
    ):
        self.api_key = api_key or os.environ.get("GOOGLE_API_KEY")
        self.model = model
        self.dimensions = dimensions
        self.task_type = task_type or "retrieval_query"
        self._client = None
        
        if not self.api_key:
            raise ValueError("Gemini API key not found")
    
    def _get_client(self):
        if self._client is None:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            self._client = genai
        return self._client
    
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        client = self._get_client()
        results = []
        for text in texts:
            result = client.embed_content(
                model=self.model,
                content=text,
                task_type=self.task_type,
                output_dimensionality=self.dimensions,
            )
            results.append(result["embedding"])
        return results


class MistralEmbeddingProvider(EmbeddingProvider):
    """Mistral AI embedding provider"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "mistral-embed",
    ):
        self.api_key = api_key or os.environ.get("MISTRAL_API_KEY")
        self.model = model
        self._client = None
        
        if not self.api_key:
            raise ValueError("Mistral API key not found")
    
    def _get_client(self):
        if self._client is None:
            from mistralai import Mistral
            self._client = Mistral(api_key=self.api_key)
        return self._client
    
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        client = self._get_client()
        response = client.embeddings.create(
            model=self.model,
            inputs=texts,
        )
        return [item.embedding for item in response.data]


class VoyageEmbeddingProvider(EmbeddingProvider):
    """Voyage AI embedding provider"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "voyage-4-large",
    ):
        self.api_key = api_key or os.environ.get("VOYAGE_API_KEY")
        self.model = model
        self._client = None
        
        if not self.api_key:
            raise ValueError("Voyage API key not found")
    
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        import aiohttp
        
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {"inputs": texts, "model": self.model}
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.voyageai.com/v1/embeddings",
                headers=headers,
                json=payload,
            ) as response:
                result = await response.json()
                return [item["embedding"] for item in result["data"]]


class OllamaEmbeddingProvider(EmbeddingProvider):
    """Ollama local embedding provider"""
    
    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "nomic-embed-text",
    ):
        self.base_url = base_url
        self.model = model
    
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        import aiohttp
        
        results = []
        async with aiohttp.ClientSession() as session:
            for text in texts:
                async with session.post(
                    f"{self.base_url}/api/embeddings",
                    json={"model": self.model, "prompt": text},
                ) as response:
                    result = await response.json()
                    results.append(result["embedding"])
        return results


class LocalEmbeddingProvider(EmbeddingProvider):
    """Local embedding provider using llama-cpp-python"""
    
    def __init__(
        self,
        model_path: Optional[str] = None,
        model_cache_dir: Optional[str] = None,
    ):
        try:
            from llama_cpp import Llama
        except ImportError:
            raise ImportError(
                "llama-cpp-python not installed. "
                "Install with: pip install llama-cpp-python"
            )
        
        self.model_path = model_path
        self.model_cache_dir = model_cache_dir
        self._model = None
    
    def _get_model(self):
        if self._model is None:
            from llama_cpp import Llama
            
            model_path = self.model_path or self._get_default_model_path()
            self._model = Llama(
                model_path=model_path,
                embedding=True,
                n_ctx=0,
                verbose=False,
            )
        return self._model
    
    def _get_default_model_path(self) -> str:
        """Get default local embedding model path"""
        cache_dir = self.model_cache_dir or os.path.expanduser("~/.cache/openclaw/models")
        return os.path.join(
            cache_dir,
            "hf:ggml-org:embeddinggemma-300m-qat-q8_0-GGUF",
            "embeddinggemma-300m-qat-Q8_0.gguf",
        )
    
    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        model = self._get_model()
        results = []
        for text in texts:
            embedding = model.create_embedding(text)
            # Handle different return formats
            if isinstance(embedding, dict):
                vec = embedding.get("embedding", embedding.get("data", []))
            elif isinstance(embedding, list):
                vec = embedding
            else:
                vec = list(embedding)
            results.append(self._sanitize_embedding(vec))
        return results
    
    def _sanitize_embedding(self, embedding: list[float]) -> list[float]:
        """Sanitize and normalize embedding vector"""
        vec = np.array(embedding, dtype=np.float32)
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec.tolist()


def sanitize_and_normalize_embedding(embedding: list[float]) -> list[float]:
    """Sanitize and normalize an embedding vector"""
    vec = np.array(embedding, dtype=np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.tolist()


async def create_embedding_provider(
    provider: str,
    model: str,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    dimensions: Optional[int] = None,
    fallback: Optional[str] = None,
    local_model_path: Optional[str] = None,
    local_model_cache_dir: Optional[str] = None,
) -> EmbeddingProviderResult:
    """
    Create an embedding provider based on the specified configuration.
    
    Args:
        provider: Provider ID ("openai", "gemini", "mistral", "voyage", "ollama", "local", "auto")
        model: Model name to use
        api_key: API key for remote providers
        base_url: Base URL for API (OpenAI-compatible)
        dimensions: Output dimensions for embeddings
        fallback: Fallback provider if primary fails
        local_model_path: Path to local model file
        local_model_cache_dir: Cache directory for local models
    
    Returns:
        EmbeddingProviderResult with provider instance
    """
    
    def create_provider_internal(provider_id: str) -> EmbeddingProvider:
        if provider_id == "local":
            return LocalEmbeddingProvider(
                model_path=local_model_path,
                model_cache_dir=local_model_cache_dir,
            )
        elif provider_id == "ollama":
            return OllamaEmbeddingProvider(
                base_url=base_url or "http://localhost:11434",
                model=model,
            )
        elif provider_id == "gemini":
            return GeminiEmbeddingProvider(
                api_key=api_key,
                model=model,
                dimensions=dimensions,
            )
        elif provider_id == "voyage":
            return VoyageEmbeddingProvider(
                api_key=api_key,
                model=model,
            )
        elif provider_id == "mistral":
            return MistralEmbeddingProvider(
                api_key=api_key,
                model=model,
            )
        else:  # openai
            return OpenAIEmbeddingProvider(
                api_key=api_key,
                base_url=base_url,
                model=model,
                dimensions=dimensions,
            )
    
    if provider == "auto":
        # Try providers in order
        provider_order = ["openai", "gemini", "mistral", "voyage"]
        
        # Try local first if model path is available
        if local_model_path and os.path.isfile(local_model_path):
            try:
                p = create_provider_internal("local")
                return EmbeddingProviderResult(
                    provider=p,
                    requested_provider="auto",
                )
            except Exception as e:
                pass
        
        missing_key_errors = []
        for p_id in provider_order:
            try:
                p = create_provider_internal(p_id)
                return EmbeddingProviderResult(
                    provider=p,
                    requested_provider="auto",
                )
            except ValueError as e:
                if "key not found" in str(e).lower():
                    missing_key_errors.append(str(e))
                    continue
                raise
        
        # All providers failed due to missing keys - return null for FTS-only mode
        return EmbeddingProviderResult(
            provider=None,
            requested_provider="auto",
            provider_unavailable_reason="\n".join(missing_key_errors),
        )
    
    try:
        p = create_provider_internal(provider)
        return EmbeddingProviderResult(
            provider=p,
            requested_provider=provider,
        )
    except Exception as e:
        if fallback and fallback != "none" and fallback != provider:
            try:
                p = create_provider_internal(fallback)
                return EmbeddingProviderResult(
                    provider=p,
                    requested_provider=provider,
                    fallback_from=provider,
                    fallback_reason=str(e),
                )
            except Exception as fallback_err:
                return EmbeddingProviderResult(
                    provider=None,
                    requested_provider=provider,
                    fallback_from=provider,
                    fallback_reason=str(e),
                    provider_unavailable_reason=f"{str(e)}\n\nFallback to {fallback} failed: {str(fallback_err)}",
                )
        
        # Check if auth error - return null for FTS-only mode
        if "key not found" in str(e).lower():
            return EmbeddingProviderResult(
                provider=None,
                requested_provider=provider,
                provider_unavailable_reason=str(e),
            )
        raise


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Calculate cosine similarity between two vectors"""
    vec_a = np.array(a, dtype=np.float32)
    vec_b = np.array(b, dtype=np.float32)
    
    norm_a = np.linalg.norm(vec_a)
    norm_b = np.linalg.norm(vec_b)
    
    if norm_a == 0 or norm_b == 0:
        return 0.0
    
    return float(np.dot(vec_a, vec_b) / (norm_a * norm_b))


def vector_to_bytes(embedding: list[float]) -> bytes:
    """Convert embedding vector to bytes for SQLite storage"""
    return np.array(embedding, dtype=np.float32).tobytes()


def bytes_to_vector(data: bytes, dimensions: int) -> list[float]:
    """Convert bytes back to embedding vector"""
    return np.frombuffer(data, dtype=np.float32).tolist()
