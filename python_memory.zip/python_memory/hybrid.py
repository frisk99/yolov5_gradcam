"""
OpenClaw Memory System - Python Implementation
Hybrid search combining vector and keyword (BM25) search
"""

import math
import re
from dataclasses import dataclass
from typing import Optional
from collections import defaultdict

# Note: Using local types module, not Python's built-in 'types'
from .memory_types import MemorySearchResult, MemorySource  # type: ignore


@dataclass
class VectorResult:
    """Vector search result"""
    id: str
    path: str
    start_line: int
    end_line: int
    source: MemorySource
    snippet: str
    vector_score: float


@dataclass
class KeywordResult:
    """Keyword (BM25) search result"""
    id: str
    path: str
    start_line: int
    end_line: int
    source: MemorySource
    snippet: str
    text_score: float


def bm25_rank_to_score(rank: float, k1: float = 1.2) -> float:
    """
    Convert BM25 rank to a 0-1 score.
    BM25 returns negative values where lower (more negative) is better.
    """
    if rank >= 0:
        return 0.0
    # Normalize: convert to positive score where higher is better
    return min(1.0, abs(rank) / (abs(rank) + k1))


def build_fts_query(raw: str) -> Optional[str]:
    """
    Build a full-text search query from raw input.
    Returns None if the query is empty or invalid.
    """
    cleaned = raw.strip()
    if not cleaned:
        return None
    
    # Escape special FTS characters
    escaped = re.sub(r'["*+-]()~]', r'\\\g<0>', cleaned)
    
    # Split into terms and join with AND
    terms = escaped.split()
    if not terms:
        return None
    
    return " ".join(terms)


def extract_keywords(query: str) -> list[str]:
    """
    Extract keywords from a conversational query for better FTS matching.
    e.g., "that thing we discussed about the API" → ["discussed", "API"]
    """
    # Stop words to filter out
    stop_words = {
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "with", "by", "from", "that", "this", "it", "is", "are", "was",
        "were", "be", "been", "being", "have", "has", "had", "do", "does",
        "did", "will", "would", "could", "should", "may", "might", "must",
        "about", "into", "through", "during", "before", "after", "above",
        "below", "between", "under", "again", "further", "then", "once",
        "here", "there", "when", "where", "why", "how", "all", "each",
        "few", "more", "most", "other", "some", "such", "no", "nor", "not",
        "only", "own", "same", "so", "than", "too", "very", "just", "can",
        "now", "we", "you", "i", "he", "she", "they", "them", "what",
        "which", "who", "whom", "thing", "discussed", "talked", "mentioned",
    }
    
    # Extract meaningful words
    words = re.findall(r'\b[a-zA-Z]{3,}\b', query.lower())
    keywords = [w for w in words if w not in stop_words]
    
    # Also extract uppercase acronyms and proper nouns
    acronyms = re.findall(r'\b[A-Z]{2,}\b', query)
    keywords.extend([a.lower() for a in acronyms])
    
    return list(dict.fromkeys(keywords))  # Preserve order, remove duplicates


async def merge_hybrid_results(
    vector_results: list[VectorResult],
    keyword_results: list[KeywordResult],
    vector_weight: float = 0.7,
    text_weight: float = 0.3,
    mmr: Optional[dict] = None,
    temporal_decay: Optional[dict] = None,
    workspace_dir: Optional[str] = None,
) -> list[MemorySearchResult]:
    """
    Merge vector and keyword search results using Reciprocal Rank Fusion (RRF).
    
    Args:
        vector_results: Results from vector search
        keyword_results: Results from keyword (BM25) search
        vector_weight: Weight for vector scores in final fusion
        text_weight: Weight for text scores in final fusion
        mmr: MMR configuration {"enabled": bool, "lambda": float}
        temporal_decay: Temporal decay configuration {"enabled": bool, "half_life_days": int}
        workspace_dir: Workspace directory for file timestamp lookup
    
    Returns:
        Merged and ranked search results
    """
    if not vector_results and not keyword_results:
        return []
    
    # Build result key function
    def result_key(r: VectorResult | KeywordResult) -> str:
        return f"{r.source}:{r.path}:{r.start_line}:{r.end_line}"
    
    # Collect all unique results
    all_results: dict[str, dict] = {}
    
    # Normalize scores within each result set
    vector_scores = _normalize_scores([r.vector_score for r in vector_results])
    keyword_scores = _normalize_scores([r.text_score for r in keyword_results])
    
    # Add vector results
    for i, result in enumerate(vector_results):
        key = result_key(result)
        all_results[key] = {
            "id": result.id,
            "path": result.path,
            "start_line": result.start_line,
            "end_line": result.end_line,
            "source": result.source,
            "snippet": result.snippet,
            "vector_score": vector_scores[i] if i < len(vector_scores) else 0,
            "text_score": 0.0,
            "has_vector": True,
            "has_keyword": False,
        }
    
    # Add keyword results
    for i, result in enumerate(keyword_results):
        key = result_key(result)
        if key in all_results:
            all_results[key]["text_score"] = keyword_scores[i] if i < len(keyword_scores) else 0
            all_results[key]["has_keyword"] = True
        else:
            all_results[key] = {
                "id": result.id,
                "path": result.path,
                "start_line": result.start_line,
                "end_line": result.end_line,
                "source": result.source,
                "snippet": result.snippet,
                "vector_score": 0.0,
                "text_score": keyword_scores[i] if i < len(keyword_scores) else 0,
                "has_vector": False,
                "has_keyword": True,
            }
    
    # Calculate combined scores
    for entry in all_results.values():
        # Weighted combination
        combined = (
            vector_weight * entry["vector_score"] +
            text_weight * entry["text_score"]
        )
        
        # Apply temporal decay if enabled
        if temporal_decay and temporal_decay.get("enabled"):
            half_life_days = temporal_decay.get("half_life_days", 30)
            decay_factor = _calculate_temporal_decay(
                entry["path"], workspace_dir, half_life_days
            )
            combined *= decay_factor
        
        entry["combined_score"] = combined
    
    # Apply MMR if enabled
    if mmr and mmr.get("enabled"):
        lambda_param = mmr.get("lambda", 0.7)
        entries = _apply_mmr(
            list(all_results.values()),
            lambda_param=lambda_param,
        )
    else:
        entries = sorted(
            all_results.values(),
            key=lambda x: x["combined_score"],
            reverse=True,
        )
    
    # Convert to MemorySearchResult
    results = []
    for entry in entries:
        results.append(MemorySearchResult(
            path=entry["path"],
            start_line=entry["start_line"],
            end_line=entry["end_line"],
            score=entry["combined_score"],
            snippet=entry["snippet"],
            source=entry["source"],
        ))
    
    return results


def _normalize_scores(scores: list[float]) -> list[float]:
    """Min-max normalize scores to 0-1 range"""
    if not scores:
        return []
    
    min_score = min(scores)
    max_score = max(scores)
    
    if max_score == min_score:
        return [1.0 if s > 0 else 0.0 for s in scores]
    
    return [(s - min_score) / (max_score - min_score) for s in scores]


def _calculate_temporal_decay(
    path: str,
    workspace_dir: Optional[str],
    half_life_days: int,
) -> float:
    """
    Calculate temporal decay factor based on file modification time.
    Newer files get higher scores.
    """
    import os
    from datetime import datetime, timedelta
    
    if not workspace_dir or not path:
        return 1.0
    
    try:
        full_path = os.path.join(workspace_dir, path)
        if not os.path.exists(full_path):
            return 1.0
        
        mtime = os.path.getmtime(full_path)
        file_date = datetime.fromtimestamp(mtime)
        now = datetime.now()
        age_days = (now - file_date).days
        
        if age_days <= 0:
            return 1.0
        
        # Exponential decay: score = 0.5^(age / half_life)
        decay = 0.5 ** (age_days / half_life_days)
        return max(0.1, decay)  # Floor at 0.1
    except Exception:
        return 1.0


def _apply_mmr(
    results: list[dict],
    lambda_param: float = 0.7,
    max_results: Optional[int] = None,
) -> list[dict]:
    """
    Apply Maximal Marginal Relevance to balance relevance and diversity.
    
    Args:
        results: List of result dictionaries with combined_score
        lambda_param: Balance between relevance (1.0) and diversity (0.0)
        max_results: Maximum number of results to return
    
    Returns:
        MMR-ranked results
    """
    if not results:
        return []
    
    # Simple MMR implementation using snippet similarity
    selected = []
    remaining = results.copy()
    
    # Calculate pairwise similarities
    similarities: dict[tuple[int, int], float] = {}
    
    def get_similarity(i: int, j: int) -> float:
        key = (min(i, j), max(i, j))
        if key not in similarities:
            sim = _snippet_similarity(
                remaining[i]["snippet"],
                remaining[j]["snippet"],
            )
            similarities[key] = sim
        return similarities[key]
    
    while remaining and (max_results is None or len(selected) < max_results):
        if not selected:
            # First result: highest combined score
            best_idx = 0
        else:
            # MMR scoring
            best_idx = _mmr_select(
                remaining, selected, get_similarity, lambda_param
            )
        
        selected.append(remaining.pop(best_idx))
    
    return selected


def _mmr_select(
    remaining: list[dict],
    selected: list[dict],
    get_similarity: callable,
    lambda_param: float,
) -> int:
    """Select next result using MMR criterion"""
    best_score = float("-inf")
    best_idx = 0
    
    for i, rem in enumerate(remaining):
        # Relevance score
        relevance = rem["combined_score"]
        
        # Max similarity to already selected results
        max_sim = 0.0
        for sel in selected:
            # Find indices for similarity lookup
            rem_idx = remaining.index(rem)
            sel_idx = next(
                (j for j, s in enumerate(selected) if s["id"] == sel["id"]),
                -1,
            )
            if rem_idx >= 0 and sel_idx >= 0:
                sim = get_similarity(rem_idx, sel_idx)
                max_sim = max(max_sim, sim)
        
        # MMR score
        mmr_score = lambda_param * relevance - (1 - lambda_param) * max_sim
        
        if mmr_score > best_score:
            best_score = mmr_score
            best_idx = i
    
    return best_idx


def _snippet_similarity(s1: str, s2: str) -> float:
    """Calculate Jaccard similarity between two snippets"""
    # Tokenize
    tokens1 = set(_tokenize(s1))
    tokens2 = set(_tokenize(s2))
    
    if not tokens1 or not tokens2:
        return 0.0
    
    intersection = len(tokens1 & tokens2)
    union = len(tokens1 | tokens2)
    
    return intersection / union if union > 0 else 0.0


def _tokenize(text: str) -> list[str]:
    """Simple tokenization"""
    return re.findall(r'\b\w+\b', text.lower())
