#!/bin/bash
# OpenClaw Memory System - Command Test Cases
# Each command has two test cases: one that finds results and one that doesn't

set -e

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT_DIR="$(dirname "$SCRIPT_DIR")"

AGENT_ID="test-agent-$(date +%s)"
WORKSPACE="/tmp/openclaw-test-$AGENT_ID"

# Create workspace and memory files
mkdir -p "$WORKSPACE/memory"

# Change to parent directory for python -m to work
cd "$PARENT_DIR"

cat > "$WORKSPACE/memory/preferences.md" << 'EOF'
# User Preferences

## Interface
- Theme: Dark mode preferred
- Font size: Large
- Language: Chinese (Simplified)

## Notifications
- Email notifications: Enabled
- Push notifications: Disabled
- Sound: Muted

## Privacy
- Share analytics: No
- Remember history: Yes
EOF

cat > "$WORKSPACE/memory/projects.md" << 'EOF'
# Active Projects

## OpenClaw
- Role: Developer
- Start date: 2024-01-15
- Status: Active
- Repository: github.com/openclaw/openclaw

## Memory System
- Description: Python implementation of memory system
- Components: Short-term, Long-term, Vector search
- Status: In Progress
EOF

cat > "$WORKSPACE/MEMORY.md" << 'EOF'
# Memory - Agent Knowledge

## About User
- Name: Test User
- Email: test@example.com
- Location: Shanghai, China

## Preferences Summary
User prefers dark theme and large fonts for better readability.
Prefers Chinese language interface.

## Project Notes
Working on OpenClaw memory system implementation with:
- SQLite for short-term storage
- LanceDB for long-term memory
- Multiple embedding providers support
EOF

echo "=============================================="
echo "OpenClaw Memory System - Test Cases"
echo "=============================================="
echo "Agent ID: $AGENT_ID"
echo "Workspace: $WORKSPACE"
echo ""

# Test 1: status command
echo "=== Test 1: status command ==="
echo "Command: python -m python_memory status --agent-id $AGENT_ID --workspace $WORKSPACE"
python -m python_memory status --agent-id "$AGENT_ID" --workspace "$WORKSPACE"
echo ""

# Test 2: get - found (existing file) - BEFORE sync
echo "=== Test 2a: get - found (preferences.md) ==="
echo "Command: python -m python_memory get 'memory/preferences.md' --agent-id $AGENT_ID --workspace $WORKSPACE"
python -m python_memory get "memory/preferences.md" --agent-id "$AGENT_ID" --workspace "$WORKSPACE"
echo ""

# Test 3: get - not found (non-existent file)
echo "=== Test 2b: get - not found (nonexistent.md) ==="
echo "Command: python -m python_memory get 'memory/nonexistent.md' --agent-id $AGENT_ID --workspace $WORKSPACE"
python -m python_memory get "memory/nonexistent.md" --agent-id "$AGENT_ID" --workspace "$WORKSPACE"
echo ""

# Test 4: sync command
echo "=== Test 3: sync command ==="
echo "Command: python -m python_memory sync --agent-id $AGENT_ID --workspace $WORKSPACE"
python -m python_memory sync --agent-id "$AGENT_ID" --workspace "$WORKSPACE"
echo ""

# Test 5: search - found (dark theme) - AFTER sync
echo "=== Test 4a: search - found (dark theme) ==="
echo "Command: python -m python_memory search 'dark theme preference' --agent-id $AGENT_ID --workspace $WORKSPACE"
python -m python_memory search "dark theme preference" --agent-id "$AGENT_ID" --workspace "$WORKSPACE"
echo ""

# Test 6: search - not found (unrelated topic)
echo "=== Test 4b: search - not found (weather) ==="
echo "Command: python -m python_memory search 'weather forecast' --agent-id $AGENT_ID --workspace $WORKSPACE"
python -m python_memory search "weather forecast" --agent-id "$AGENT_ID" --workspace "$WORKSPACE"
echo ""

# Test 7: ltm store command
echo "=== Test 5: ltm store command ==="
echo "Command: python -m python_memory ltm store 'User likes coffee with milk' --category preference"
python -m python_memory ltm store "User likes coffee with milk" --category preference --db-path "/tmp/test-lancedb-$AGENT_ID"
echo ""

# Test 8: ltm search - found
echo "=== Test 6a: ltm search - found (coffee) ==="
echo "Command: python -m python_memory ltm search 'coffee drink' --db-path /tmp/test-lancedb-$AGENT_ID"
python -m python_memory ltm search "coffee drink" --db-path "/tmp/test-lancedb-$AGENT_ID"
echo ""

# Test 9: ltm search - not found
echo "=== Test 6b: ltm search - not found (tea) ==="
echo "Command: python -m python_memory ltm search 'tea preference' --db-path /tmp/test-lancedb-$AGENT_ID"
python -m python_memory ltm search "tea preference" --db-path "/tmp/test-lancedb-$AGENT_ID"
echo ""

# Test 10: ltm stats
echo "=== Test 7: ltm stats ==="
echo "Command: python -m python_memory ltm stats --db-path /tmp/test-lancedb-$AGENT_ID"
python -m python_memory ltm stats --db-path "/tmp/test-lancedb-$AGENT_ID"
echo ""

# Cleanup
echo "=== Cleanup ==="
rm -rf "$WORKSPACE"
rm -rf "/tmp/test-lancedb-$AGENT_ID"
echo "Test workspace cleaned up."

echo ""
echo "=============================================="
echo "All tests completed!"
echo "=============================================="
