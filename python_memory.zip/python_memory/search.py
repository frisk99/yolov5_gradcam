"""
OpenClaw Memory System - Python Implementation
Vector and keyword search operations
"""

import sqlite3
from typing import Optional, Callable
from dataclasses import dataclass

# Note: Using local types module, not Python's built-in 'types'
from .memory_types import MemorySource, MemorySearchResult  # type: ignore
from .embeddings import vector_to_bytes, cosine_similarity  # type: ignore
from .hybrid import bm25_rank_to_score, build_fts_query  # type: ignore


@dataclass
class SearchRowResult:
    """Raw search result row"""
    id: str
    path: str
    start_line: int
    end_line: int
    score: float
    snippet: str
    source: MemorySource


def truncate_utf16_safe(text: str, max_chars: int) -> str:
    """Truncate text to max characters, handling UTF-16 safely"""
    if len(text) <= max_chars:
        return text
    return text[:max_chars]


async def search_vector(
    db: sqlite3.Connection,
    vector_table: str,
    provider_model: str,
    query_vec: list[float],
    limit: int,
    snippet_max_chars: int,
    ensure_vector_ready: Callable[[int], bool],
    source_filter: tuple[str, list],
) -> list[SearchRowResult]:
    """
    Perform vector similarity search.
    
    Args:
        db: SQLite connection
        vector_table: Name of vector table
        provider_model: Model identifier for filtering
        query_vec: Query embedding vector
        limit: Maximum results to return
        snippet_max_chars: Maximum snippet length
        ensure_vector_ready: Callback to ensure vector extension is loaded
        source_filter: SQL filter and parameters for source filtering
    
    Returns:
        List of search results
    """
    if not query_vec or limit <= 0:
        return []
    
    sql_filter, filter_params = source_filter
    
    # Try using sqlite-vec extension for vector search
    if ensure_vector_ready(len(query_vec)):
        try:
            cursor = db.cursor()
            
            # Build query with vec_distance_cosine
            query = f"""
                SELECT c.id, c.path, c.start_line, c.end_line, c.text,
                       c.source,
                       vec_distance_cosine(v.embedding, ?) AS dist
                FROM {vector_table} v
                JOIN chunks c ON c.id = v.id
                WHERE c.model = ?{sql_filter}
                ORDER BY dist ASC
                LIMIT ?
            """
            
            params = [vector_to_bytes(query_vec), provider_model] + filter_params + [limit]
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            results = []
            for row in rows:
                results.append(SearchRowResult(
                    id=row[0],
                    path=row[1],
                    start_line=row[2],
                    end_line=row[3],
                    score=1.0 - row[6],  # Convert distance to similarity
                    snippet=truncate_utf16_safe(row[4], snippet_max_chars),
                    source=MemorySource(row[5]),
                ))
            return results
            
        except sqlite3.OperationalError:
            # Fallback to brute-force if vec extension fails
            pass
    
    # Fallback: load all chunks and compute similarity in Python
    candidates = list_chunks(db, provider_model, source_filter)
    scored = []
    
    for chunk in candidates:
        score = cosine_similarity(query_vec, chunk["embedding"])
        if score > 0:  # Only include positive similarities
            scored.append({**chunk, "score": score})
    
    # Sort by score descending
    scored.sort(key=lambda x: x["score"], reverse=True)
    
    results = []
    for entry in scored[:limit]:
        results.append(SearchRowResult(
            id=entry["id"],
            path=entry["path"],
            start_line=entry["start_line"],
            end_line=entry["end_line"],
            score=entry["score"],
            snippet=truncate_utf16_safe(entry["text"], snippet_max_chars),
            source=MemorySource(entry["source"]),
        ))
    
    return results


def list_chunks(
    db: sqlite3.Connection,
    provider_model: str,
    source_filter: tuple[str, list],
) -> list[dict]:
    """
    List all chunks with their embeddings.
    
    Args:
        db: SQLite connection
        provider_model: Model identifier for filtering
        source_filter: SQL filter and parameters
    
    Returns:
        List of chunk dictionaries with embeddings
    """
    sql_filter, filter_params = source_filter
    
    cursor = db.cursor()
    query = f"""
        SELECT id, path, start_line, end_line, text, embedding, source
        FROM chunks
        WHERE model = ?{sql_filter}
    """
    
    params = [provider_model] + filter_params
    cursor.execute(query, params)
    rows = cursor.fetchall()
    
    chunks = []
    for row in rows:
        embedding = parse_embedding(row[5])
        chunks.append({
            "id": row[0],
            "path": row[1],
            "start_line": row[2],
            "end_line": row[3],
            "text": row[4],
            "embedding": embedding,
            "source": row[6],
        })
    
    return chunks


def parse_embedding(data: bytes | str | list) -> list[float]:
    """Parse embedding from database storage format"""
    if isinstance(data, bytes):
        import numpy as np
        return np.frombuffer(data, dtype=np.float32).tolist()
    elif isinstance(data, str):
        # JSON string format
        import json
        return json.loads(data)
    elif isinstance(data, list):
        return data
    return []


async def search_keyword(
    db: sqlite3.Connection,
    fts_table: str,
    provider_model: Optional[str],
    query: str,
    limit: int,
    snippet_max_chars: int,
    source_filter: tuple[str, list],
    build_fts_query_fn: Callable[[str], Optional[str]],
    bm25_rank_to_score_fn: Callable[[float], float],
) -> list[dict]:
    """
    Perform keyword search using SQLite FTS5.
    
    Args:
        db: SQLite connection
        fts_table: Name of FTS table
        provider_model: Model identifier (None for FTS-only mode)
        query: Search query
        limit: Maximum results
        snippet_max_chars: Maximum snippet length
        source_filter: SQL filter for sources
        build_fts_query_fn: Function to build FTS query
        bm25_rank_to_score_fn: Function to convert BM25 rank to score
    
    Returns:
        List of search results with text scores
    """
    if limit <= 0:
        return []
    
    fts_query = build_fts_query_fn(query)
    if not fts_query:
        return []
    
    sql_filter, filter_params = source_filter
    
    # When provider_model is None (FTS-only mode), search all models
    model_clause = "AND model = ?" if provider_model else ""
    model_params = [provider_model] if provider_model else []
    
    cursor = db.cursor()
    query_sql = f"""
        SELECT id, path, source, start_line, end_line, text,
               bm25({fts_table}) AS rank
        FROM {fts_table}
        WHERE {fts_table} MATCH ?{model_clause}{sql_filter}
        ORDER BY rank ASC
        LIMIT ?
    """
    
    params = [fts_query] + model_params + filter_params + [limit]
    cursor.execute(query_sql, params)
    rows = cursor.fetchall()
    
    results = []
    for row in rows:
        text_score = bm25_rank_to_score_fn(row[6])
        results.append({
            "id": row[0],
            "path": row[1],
            "start_line": row[3],
            "end_line": row[4],
            "score": text_score,
            "text_score": text_score,
            "snippet": truncate_utf16_safe(row[5], snippet_max_chars),
            "source": MemorySource(row[2]),
        })
    
    return results


def build_source_filter(
    sources: list[MemorySource],
    table_alias: str = "",
) -> tuple[str, list]:
    """
    Build SQL filter for source filtering.
    
    Args:
        sources: List of sources to filter by
        table_alias: Table alias to use (e.g., "c." for chunks table, "" for FTS)
    
    Returns:
        Tuple of (SQL clause, parameters)
    """
    if not sources:
        return ("", [])
    
    placeholders = ",".join("?" for _ in sources)
    prefix = table_alias if table_alias else ""
    return (f" AND {prefix}source IN ({placeholders})", [s.value for s in sources])
