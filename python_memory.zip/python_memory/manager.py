"""
OpenClaw Memory System - Python Implementation
Memory Index Manager - Core memory management with SQLite storage
"""

import os
import json
import hashlib
import sqlite3
import threading
import asyncio
import time
from pathlib import Path
from typing import Optional, Callable, Any
from dataclasses import dataclass, field
from collections import defaultdict
import re

# Note: Using local types module, not Python's built-in 'types'
from .memory_types import (  # type: ignore
    MemorySource,
    MemorySearchResult,
    MemoryProviderStatus,
    MemoryEmbeddingProbeResult,
    MemorySearchManager,
)
from .embeddings import (  # type: ignore
    EmbeddingProvider,
    EmbeddingProviderResult,
    create_embedding_provider,
    cosine_similarity,
    vector_to_bytes,
    bytes_to_vector,
)
from .search import search_vector, search_keyword, build_source_filter, parse_embedding  # type: ignore
from .hybrid import (  # type: ignore
    merge_hybrid_results,
    build_fts_query,
    bm25_rank_to_score,
    extract_keywords,
    VectorResult,
    KeywordResult,
)


# Database constants
VECTOR_TABLE = "chunks_vec"
FTS_TABLE = "chunks_fts"
EMBEDDING_CACHE_TABLE = "embedding_cache"
SNIPPET_MAX_CHARS = 700
BATCH_FAILURE_LIMIT = 2


@dataclass
class MemoryChunk:
    """A chunk of memory content"""
    id: str
    path: str
    start_line: int
    end_line: int
    text: str
    source: MemorySource
    model: str
    embedding: Optional[list[float]] = None
    created_at: float = field(default_factory=time.time)


@dataclass
class ChunkingConfig:
    """Text chunking configuration"""
    tokens: int = 400
    overlap: int = 80


@dataclass
class SyncConfig:
    """Sync configuration"""
    on_session_start: bool = True
    on_search: bool = True
    watch: bool = True
    watch_debounce_ms: int = 1500
    interval_minutes: int = 0


@dataclass
class QueryConfig:
    """Query configuration"""
    max_results: int = 6
    min_score: float = 0.35
    hybrid_enabled: bool = True
    vector_weight: float = 0.7
    text_weight: float = 0.3
    candidate_multiplier: float = 4.0
    mmr_enabled: bool = False
    mmr_lambda: float = 0.7
    temporal_decay_enabled: bool = False
    temporal_decay_half_life_days: int = 30


@dataclass
class CacheConfig:
    """Embedding cache configuration"""
    enabled: bool = True
    max_entries: Optional[int] = None


@dataclass
class VectorConfig:
    """Vector storage configuration"""
    enabled: bool = True
    extension_path: Optional[str] = None


@dataclass
class StoreConfig:
    """Storage configuration"""
    driver: str = "sqlite"
    path: str = ""
    vector: VectorConfig = field(default_factory=VectorConfig)


@dataclass
class ResolvedMemoryConfig:
    """Resolved memory configuration"""
    enabled: bool = True
    sources: list[MemorySource] = field(default_factory=lambda: [MemorySource.MEMORY])
    extra_paths: list[str] = field(default_factory=list)
    provider: str = "auto"
    model: str = ""
    fallback: str = "none"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    dimensions: Optional[int] = None
    local_model_path: Optional[str] = None
    local_model_cache_dir: Optional[str] = None
    store: StoreConfig = field(default_factory=StoreConfig)
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    sync: SyncConfig = field(default_factory=SyncConfig)
    query: QueryConfig = field(default_factory=QueryConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)


class MemoryIndexManager(MemorySearchManager):
    """
    Memory Index Manager for OpenClaw Python implementation.
    
    Provides:
    - SQLite-based storage for memory chunks
    - Vector search using sqlite-vec extension
    - Full-text search using SQLite FTS5
    - Hybrid search combining vector and keyword search
    - Embedding caching
    - File watching for automatic sync
    """
    
    _instances: dict[str, "MemoryIndexManager"] = {}
    _lock = threading.Lock()
    
    def __init__(
        self,
        agent_id: str,
        workspace_dir: str,
        config: ResolvedMemoryConfig,
        provider_result: Optional[EmbeddingProviderResult] = None,
    ):
        self.agent_id = agent_id
        self.workspace_dir = workspace_dir
        self.config = config
        self.provider_result = provider_result
        self.provider: Optional[EmbeddingProvider] = None
        self._closed = False
        self._dirty = False
        self._db: Optional[sqlite3.Connection] = None
        self._vec_available: Optional[bool] = None
        self._fts_available: bool = False
        self._vector_dims: Optional[int] = None
        self._embedding_cache: dict[str, list[float]] = {}
        self._watch_task: Optional[asyncio.Task] = None
        self._interval_task: Optional[asyncio.Task] = None
        self._debounce_timer: Optional[asyncio.TimerHandle] = None
        self._sync_lock = asyncio.Lock()
        self._batch_failure_count = 0
        self._batch_failure_last_error: Optional[str] = None
        self._readonly_recovery_attempts = 0
        self._readonly_recovery_successes = 0
        self._readonly_recovery_failures = 0
    
    @classmethod
    async def get(
        cls,
        agent_id: str,
        workspace_dir: str,
        config: ResolvedMemoryConfig,
    ) -> Optional["MemoryIndexManager"]:
        """Get or create a MemoryIndexManager instance"""
        key = f"{agent_id}:{workspace_dir}"
        
        with cls._lock:
            if key in cls._instances:
                return cls._instances[key]
        
        # Create embedding provider
        provider_result = await create_embedding_provider(
            provider=config.provider,
            model=config.model or cls._get_default_model(config.provider),
            api_key=config.api_key,
            base_url=config.base_url,
            dimensions=config.dimensions,
            fallback=config.fallback,
            local_model_path=config.local_model_path,
            local_model_cache_dir=config.local_model_cache_dir,
        )
        
        manager = cls(
            agent_id=agent_id,
            workspace_dir=workspace_dir,
            config=config,
            provider_result=provider_result,
        )
        manager.provider = provider_result.provider
        
        # Initialize database
        manager._init_database()
        
        with cls._lock:
            cls._instances[key] = manager
        
        return manager
    
    @staticmethod
    def _get_default_model(provider: str) -> str:
        """Get default model for provider"""
        defaults = {
            "openai": "text-embedding-3-small",
            "gemini": "gemini-embedding-001",
            "voyage": "voyage-4-large",
            "mistral": "mistral-embed",
            "ollama": "nomic-embed-text",
        }
        return defaults.get(provider, "")
    
    def _init_database(self) -> None:
        """Initialize SQLite database with schema"""
        db_path = self.config.store.path
        if not db_path:
            db_path = os.path.join(
                os.path.expanduser("~/.openclaw/state/memory"),
                f"{self.agent_id}.sqlite",
            )
            self.config.store.path = db_path
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self._db = sqlite3.connect(db_path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        
        # Enable WAL mode for better concurrency
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA busy_timeout=5000")
        
        # Create schema
        self._ensure_schema()
    
    def _ensure_schema(self) -> None:
        """Create database schema if not exists"""
        db = self._db
        cursor = db.cursor()
        
        # Files table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS files (
                id TEXT PRIMARY KEY,
                path TEXT NOT NULL,
                source TEXT NOT NULL,
                hash TEXT NOT NULL,
                size INTEGER NOT NULL,
                mtime REAL NOT NULL,
                model TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )
        """)
        
        # Chunks table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id TEXT PRIMARY KEY,
                path TEXT NOT NULL,
                start_line INTEGER NOT NULL,
                end_line INTEGER NOT NULL,
                text TEXT NOT NULL,
                source TEXT NOT NULL,
                model TEXT NOT NULL,
                hash TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )
        """)
        
        # Create indexes
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(path)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_chunks_source ON chunks(source)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_chunks_model ON chunks(model)")
        
        # Vector table (using BLOB for embedding storage)
        if self.config.store.vector.enabled:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS chunks_vec (
                    id TEXT PRIMARY KEY,
                    embedding BLOB NOT NULL,
                    model TEXT NOT NULL,
                    FOREIGN KEY (id) REFERENCES chunks(id) ON DELETE CASCADE
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_vec_model ON chunks_vec(model)")
        
        # Embedding cache
        if self.config.cache.enabled:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS embedding_cache (
                    hash TEXT PRIMARY KEY,
                    embedding BLOB NOT NULL,
                    model TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
            """)
        
        # FTS5 virtual table
        cursor.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
                path,
                text,
                source,
                model,
                content='chunks',
                content_rowid='rowid'
            )
        """)
        
        # Create triggers for FTS
        cursor.execute("""
            CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
                INSERT INTO chunks_fts(rowid, path, text, source, model)
                VALUES (NEW.rowid, NEW.path, NEW.text, NEW.source, NEW.model);
            END
        """)
        
        cursor.execute("""
            CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
                INSERT INTO chunks_fts(chunks_fts, rowid, path, text, source, model)
                VALUES('delete', OLD.rowid, OLD.path, OLD.text, OLD.source, OLD.model);
            END
        """)
        
        cursor.execute("""
            CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE ON chunks BEGIN
                INSERT INTO chunks_fts(chunks_fts, rowid, path, text, source, model)
                VALUES('delete', OLD.rowid, OLD.path, OLD.text, OLD.source, OLD.model);
                INSERT INTO chunks_fts(rowid, path, text, source, model)
                VALUES (NEW.rowid, NEW.path, NEW.text, NEW.source, NEW.model);
            END
        """)
        
        # Read meta
        self._read_meta()
        
        db.commit()
    
    def _read_meta(self) -> None:
        """Read metadata from database"""
        cursor = self._db.cursor()
        cursor.execute("PRAGMA user_version")
        row = cursor.fetchone()
        if row:
            version = row[0]
            # Extract dimensions from version or store
            # For now, we'll detect from existing data
    
    def _compute_file_hash(self, content: str) -> str:
        """Compute hash for file content"""
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def _compute_chunk_id(self, path: str, start_line: int, end_line: int) -> str:
        """Compute unique chunk ID"""
        key = f"{path}:{start_line}:{end_line}"
        return hashlib.sha256(key.encode()).hexdigest()[:16]
    
    async def _get_embedding(self, text: str) -> list[float]:
        """Get embedding for text, using cache if available"""
        if not self.provider:
            return []
        
        # Check cache
        if self.config.cache.enabled:
            hash_key = hashlib.sha256(text.encode()).hexdigest()
            if hash_key in self._embedding_cache:
                return self._embedding_cache[hash_key]
            
            # Try database cache
            cursor = self._db.cursor()
            cursor.execute(
                "SELECT embedding FROM embedding_cache WHERE hash = ? AND model = ?",
                (hash_key, self.provider.model),
            )
            row = cursor.fetchone()
            if row:
                embedding = parse_embedding(row[0])
                self._embedding_cache[hash_key] = embedding
                return embedding
        
        # Generate embedding
        embedding = await self.provider.embed_query(text)
        
        # Store in cache
        if self.config.cache.enabled:
            hash_key = hashlib.sha256(text.encode()).hexdigest()
            self._embedding_cache[hash_key] = embedding
            
            # Also store in database
            cursor = self._db.cursor()
            cursor.execute(
                """INSERT OR REPLACE INTO embedding_cache (hash, embedding, model, created_at)
                   VALUES (?, ?, ?, ?)""",
                (hash_key, vector_to_bytes(embedding), self.provider.model, time.time()),
            )
            self._db.commit()
            
            # Evict old entries if needed
            if self.config.cache.max_entries:
                self._evict_cache_entries()
        
        return embedding
    
    def _evict_cache_entries(self) -> None:
        """Evict old cache entries if over limit"""
        if not self.config.cache.max_entries:
            return
        
        cursor = self._db.cursor()
        cursor.execute("SELECT COUNT(*) FROM embedding_cache")
        count = cursor.fetchone()[0]
        
        if count > self.config.cache.max_entries:
            # Remove oldest entries
            to_delete = count - self.config.cache.max_entries
            cursor.execute("""
                DELETE FROM embedding_cache
                WHERE hash IN (
                    SELECT hash FROM embedding_cache
                    ORDER BY created_at ASC
                    LIMIT ?
                )
            """, (to_delete,))
            self._db.commit()
        
        # Also clear in-memory cache
        if len(self._embedding_cache) > self.config.cache.max_entries:
            # Keep most recent
            keys = list(self._embedding_cache.keys())
            for key in keys[:len(keys) - self.config.cache.max_entries]:
                del self._embedding_cache[key]
    
    def _chunk_text(self, text: str, path: str, source: MemorySource) -> list[MemoryChunk]:
        """Split text into chunks"""
        tokens = self.config.chunking.tokens
        overlap = self.config.chunking.overlap
        
        # Simple character-based chunking (approximate)
        # For production, use a proper tokenizer
        chars_per_token = 4  # Rough estimate
        chars_per_chunk = tokens * chars_per_token
        overlap_chars = overlap * chars_per_token
        
        chunks = []
        lines = text.split("\n")
        current_chunk_lines = []
        current_chars = 0
        start_line = 1
        
        for i, line in enumerate(lines, 1):
            line_chars = len(line) + 1  # +1 for newline
            
            if current_chars + line_chars > chars_per_chunk and current_chunk_lines:
                # Create chunk
                chunk_text = "\n".join(current_chunk_lines)
                end_line = i - 1
                
                chunks.append(MemoryChunk(
                    id=self._compute_chunk_id(path, start_line, end_line),
                    path=path,
                    start_line=start_line,
                    end_line=end_line,
                    text=chunk_text,
                    source=source,
                    model=self.provider.model if self.provider else "",
                ))
                
                # Keep overlap
                overlap_lines = []
                overlap_chars_count = 0
                for prev_line in reversed(current_chunk_lines):
                    if overlap_chars_count + len(prev_line) <= overlap_chars:
                        overlap_lines.insert(0, prev_line)
                        overlap_chars_count += len(prev_line) + 1
                    else:
                        break
                
                current_chunk_lines = overlap_lines
                current_chars = overlap_chars_count
                start_line = i - len(overlap_lines)
            
            current_chunk_lines.append(line)
            current_chars += line_chars
        
        # Final chunk
        if current_chunk_lines:
            chunk_text = "\n".join(current_chunk_lines)
            chunks.append(MemoryChunk(
                id=self._compute_chunk_id(path, start_line, len(lines)),
                path=path,
                start_line=start_line,
                end_line=len(lines),
                text=chunk_text,
                source=source,
                model=self.provider.model if self.provider else "",
            ))
        
        return chunks
    
    async def _index_file(self, path: str, source: MemorySource) -> None:
        """Index a single file"""
        abs_path = os.path.join(self.workspace_dir, path) if not os.path.isabs(path) else path
        
        if not os.path.exists(abs_path):
            return
        
        try:
            with open(abs_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            return
        
        file_hash = self._compute_file_hash(content)
        stat = os.stat(abs_path)
        
        cursor = self._db.cursor()
        
        # Check if file already indexed
        cursor.execute(
            "SELECT hash FROM files WHERE path = ? AND source = ?",
            (path, source.value),
        )
        existing = cursor.fetchone()
        
        if existing and existing[0] == file_hash:
            return  # No changes
        
        # Delete old chunks
        if existing:
            cursor.execute(
                "DELETE FROM chunks WHERE path = ? AND source = ?",
                (path, source.value),
            )
        
        # Create chunks
        chunks = self._chunk_text(content, path, source)
        
        # Insert file record
        now = time.time()
        cursor.execute("""
            INSERT OR REPLACE INTO files (id, path, source, hash, size, mtime, model, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            self._compute_chunk_id(path, 0, 0),
            path,
            source.value,
            file_hash,
            stat.st_size,
            stat.st_mtime,
            self.provider.model if self.provider else "",
            now,
            now,
        ))
        
        # Insert chunks
        for chunk in chunks:
            cursor.execute("""
                INSERT OR REPLACE INTO chunks (id, path, start_line, end_line, text, source, model, hash, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                chunk.id,
                chunk.path,
                chunk.start_line,
                chunk.end_line,
                chunk.text,
                chunk.source.value,
                chunk.model,
                self._compute_file_hash(chunk.text),
                now,
                now,
            ))
            
            # Store vector if enabled
            if self.config.store.vector.enabled and self.provider:
                embedding = await self._get_embedding(chunk.text)
                if embedding:
                    cursor.execute("""
                        INSERT OR REPLACE INTO chunks_vec (id, embedding, model)
                        VALUES (?, ?, ?)
                    """, (chunk.id, vector_to_bytes(embedding), self.provider.model))
        
        self._db.commit()
        self._dirty = False
    
    async def sync(
        self,
        reason: Optional[str] = None,
        force: bool = False,
        session_files: Optional[list[str]] = None,
        progress: Optional[Callable] = None,
    ) -> None:
        """Sync memory index with source files"""
        async with self._sync_lock:
            try:
                await self._do_sync(reason, force, session_files, progress)
            except sqlite3.OperationalError as e:
                if "readonly" in str(e).lower():
                    await self._handle_readonly_error()
                    await self._do_sync(reason, force, session_files, progress)
                else:
                    raise
    
    async def _handle_readonly_error(self) -> None:
        """Handle readonly database error by reopening"""
        self._readonly_recovery_attempts += 1
        
        try:
            self._db.close()
        except Exception:
            pass
        
        self._db = None
        self._vec_available = None
        self._init_database()
    
    async def _do_sync(
        self,
        reason: Optional[str] = None,
        force: bool = False,
        session_files: Optional[list[str]] = None,
        progress: Optional[Callable] = None,
    ) -> None:
        """Perform the actual sync"""
        files_to_index = []
        
        # Collect files from memory directories
        if MemorySource.MEMORY in self.config.sources:
            memory_dir = os.path.join(self.workspace_dir, "memory")
            if os.path.exists(memory_dir):
                for root, _, files in os.walk(memory_dir):
                    for file in files:
                        if file.endswith(".md"):
                            rel_path = os.path.relpath(os.path.join(root, file), self.workspace_dir)
                            files_to_index.append((rel_path, MemorySource.MEMORY))
        
        # Index MEMORY.md if exists
        memory_md = os.path.join(self.workspace_dir, "MEMORY.md")
        if os.path.exists(memory_md):
            files_to_index.append(("MEMORY.md", MemorySource.MEMORY))
        
        # Index extra paths
        for extra_path in self.config.extra_paths:
            abs_path = os.path.abspath(extra_path)
            if os.path.isfile(abs_path) and abs_path.endswith(".md"):
                rel_path = os.path.relpath(abs_path, self.workspace_dir)
                files_to_index.append((rel_path, MemorySource.MEMORY))
            elif os.path.isdir(abs_path):
                for root, _, files in os.walk(abs_path):
                    for file in files:
                        if file.endswith(".md"):
                            full_path = os.path.join(root, file)
                            rel_path = os.path.relpath(full_path, self.workspace_dir)
                            files_to_index.append((rel_path, MemorySource.MEMORY))
        
        # Index session files
        if MemorySource.SESSIONS in self.config.sources:
            sessions_dir = os.path.join(
                os.path.expanduser("~/.openclaw/agents"),
                self.agent_id,
                "sessions",
            )
            if os.path.exists(sessions_dir):
                for file in os.listdir(sessions_dir):
                    if file.endswith(".jsonl"):
                        rel_path = os.path.relpath(
                            os.path.join(sessions_dir, file),
                            self.workspace_dir,
                        )
                        files_to_index.append((rel_path, MemorySource.SESSIONS))
        
        if progress:
            progress({"completed": 0, "total": len(files_to_index), "label": f"Indexing files ({reason or 'sync'})"})
        
        for i, (path, source) in enumerate(files_to_index):
            await self._index_file(path, source)
            if progress:
                progress({"completed": i + 1, "total": len(files_to_index), "label": f"Indexed {path}"})
        
        self._dirty = False
    
    async def search(
        self,
        query: str,
        max_results: Optional[int] = None,
        min_score: Optional[float] = None,
        session_key: Optional[str] = None,
    ) -> list[MemorySearchResult]:
        """Search memory for relevant results"""
        cleaned = query.strip()
        if not cleaned:
            return []
        
        max_results = max_results or self.config.query.max_results
        min_score = min_score or self.config.query.min_score
        
        # Trigger sync if dirty
        if self.config.sync.on_search and self._dirty:
            asyncio.create_task(self.sync(reason="search"))
        
        # FTS-only mode (no embedding provider)
        if not self.provider:
            if not self._fts_available:
                return []
            
            # Extract keywords for better matching
            keywords = extract_keywords(cleaned)
            search_terms = keywords if keywords else [cleaned]
            
            # Search with each keyword
            all_results = []
            for term in search_terms:
                results = await self._search_keyword(term, max_results)
                all_results.extend(results)
            
            # Deduplicate and sort
            seen = {}
            for r in all_results:
                key = f"{r.source}:{r.path}:{r.start_line}:{r.end_line}"
                if key not in seen or r.score > seen[key].score:
                    seen[key] = r
            
            results = sorted(seen.values(), key=lambda x: x.score, reverse=True)
            return [r for r in results if r.score >= min_score][:max_results]
        
        # Hybrid search
        hybrid = self.config.query.hybrid_enabled
        candidate_multiplier = self.config.query.candidate_multiplier
        candidates = max(1, int(max_results * candidate_multiplier))
        
        keyword_results = []
        if hybrid and self._fts_available:
            keyword_results = await self._search_keyword(cleaned, candidates)
        
        # Vector search
        query_vec = await self._get_embedding(cleaned)
        vector_results = []
        if query_vec and any(v != 0 for v in query_vec):
            vector_results = await self._search_vector(query_vec, candidates)
        
        # Merge results
        if not hybrid or not self._fts_available:
            filtered = [r for r in vector_results if r.score >= min_score]
            return filtered[:max_results]
        
        # Hybrid merge
        merged = await merge_hybrid_results(
            vector_results=[VectorResult(
                id=r.id,
                path=r.path,
                start_line=r.start_line,
                end_line=r.end_line,
                source=r.source,
                snippet=r.snippet,
                vector_score=r.score,
            ) for r in vector_results],
            keyword_results=[KeywordResult(
                id=r["id"],
                path=r["path"],
                start_line=r["start_line"],
                end_line=r["end_line"],
                source=r["source"],
                snippet=r["snippet"],
                text_score=r["text_score"],
            ) for r in keyword_results],
            vector_weight=self.config.query.vector_weight,
            text_weight=self.config.query.text_weight,
            mmr={"enabled": self.config.query.mmr_enabled, "lambda": self.config.query.mmr_lambda} if self.config.query.mmr_enabled else None,
            temporal_decay={
                "enabled": self.config.query.temporal_decay_enabled,
                "half_life_days": self.config.query.temporal_decay_half_life_days,
            } if self.config.query.temporal_decay_enabled else None,
            workspace_dir=self.workspace_dir,
        )
        
        # Apply min_score filter
        strict = [r for r in merged if r.score >= min_score]
        if strict:
            return strict[:max_results]
        
        # Relaxed filter for keyword-only matches
        relaxed_min = min(min_score, self.config.query.text_weight)
        keyword_keys = {f"{r['source']}:{r['path']}:{r['start_line']}:{r['end_line']}" for r in keyword_results}
        
        relaxed = [
            r for r in merged
            if f"{r.source}:{r.path}:{r.start_line}:{r.end_line}" in keyword_keys
            and r.score >= relaxed_min
        ]
        return relaxed[:max_results]
    
    async def _search_vector(
        self,
        query_vec: list[float],
        limit: int,
    ) -> list[MemorySearchResult]:
        """Perform vector search"""
        source_filter = build_source_filter(list(self.config.sources))
        
        results = await search_vector(
            db=self._db,
            vector_table=VECTOR_TABLE,
            provider_model=self.provider.model if self.provider else "",
            query_vec=query_vec,
            limit=limit,
            snippet_max_chars=SNIPPET_MAX_CHARS,
            ensure_vector_ready=self._ensure_vector_ready,
            source_filter=source_filter,
        )
        
        return [MemorySearchResult(
            path=r.path,
            start_line=r.start_line,
            end_line=r.end_line,
            score=r.score,
            snippet=r.snippet,
            source=r.source,
        ) for r in results]
    
    async def _search_keyword(
        self,
        query: str,
        limit: int,
    ) -> list[dict]:
        """Perform keyword search"""
        if not self._fts_available:
            return []
        
        # FTS table doesn't use table alias
        source_filter = build_source_filter(list(self.config.sources), table_alias="")
        
        results = await search_keyword(
            db=self._db,
            fts_table=FTS_TABLE,
            provider_model=self.provider.model if self.provider else None,
            query=query,
            limit=limit,
            snippet_max_chars=SNIPPET_MAX_CHARS,
            source_filter=source_filter,
            build_fts_query_fn=build_fts_query,
            bm25_rank_to_score_fn=bm25_rank_to_score,
        )
        
        return results
    
    def _ensure_vector_ready(self, dimensions: int) -> bool:
        """Check if vector extension is available"""
        if self._vec_available is not None:
            return self._vec_available
        
        try:
            # Try loading sqlite-vec
            import sqlite_vec
            
            self._db.enable_load_extension(True)
            sqlite_vec.load(self._db)
            self._db.enable_load_extension(False)
            self._vec_available = True
            self._vector_dims = dimensions
            return True
        except Exception:
            self._vec_available = False
            return False
    
    async def read_file(
        self,
        rel_path: str,
        from_line: Optional[int] = None,
        lines: Optional[int] = None,
    ) -> dict:
        """Read a snippet from a memory file"""
        raw_path = rel_path.strip()
        if not raw_path:
            return {"text": "", "path": rel_path, "disabled": True, "error": "path required"}
        
        # Resolve path
        if os.path.isabs(raw_path):
            abs_path = os.path.normpath(raw_path)
        else:
            abs_path = os.path.normpath(os.path.join(self.workspace_dir, raw_path))
        
        # Security check: ensure path is within workspace or allowed extra paths
        rel = os.path.relpath(abs_path, self.workspace_dir)
        in_workspace = not rel.startswith("..") and not os.path.isabs(rel)
        
        allowed = in_workspace and self._is_memory_path(rel)
        
        if not allowed:
            for extra in self.config.extra_paths:
                extra_abs = os.path.abspath(extra)
                if abs_path == extra_abs or abs_path.startswith(extra_abs + os.sep):
                    if abs_path.endswith(".md"):
                        allowed = True
                        break
        
        if not allowed or not abs_path.endswith(".md"):
            return {"text": "", "path": rel_path, "disabled": True, "error": "path not allowed"}
        
        # Read file
        try:
            stat_result = os.stat(abs_path)
        except FileNotFoundError:
            return {"text": "", "path": rel_path}
        except Exception as e:
            return {"text": "", "path": rel_path, "disabled": True, "error": str(e)}
        
        try:
            with open(abs_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            return {"text": "", "path": rel_path, "disabled": True, "error": str(e)}
        
        # Apply line range if specified
        if from_line is not None or lines is not None:
            file_lines = content.split("\n")
            start = max(1, from_line or 1)
            count = lines or len(file_lines)
            slice_lines = file_lines[start - 1 : start - 1 + count]
            content = "\n".join(slice_lines)
        
        return {"text": content, "path": rel_path}
    
    def _is_memory_path(self, path: str) -> bool:
        """Check if path is a valid memory path"""
        if path == "MEMORY.md":
            return True
        if path.startswith("memory" + os.sep) or path.startswith("memory/"):
            return True
        return False
    
    def status(self) -> MemoryProviderStatus:
        """Get current status"""
        cursor = self._db.cursor()
        
        # Count files - no table alias needed
        source_filter = build_source_filter(list(self.config.sources), table_alias="")
        sql_filter, filter_params = source_filter
        
        cursor.execute(f"SELECT COUNT(*) FROM files WHERE 1=1{sql_filter}", filter_params)
        files_count = cursor.fetchone()[0]
        
        cursor.execute(f"SELECT COUNT(*) FROM chunks WHERE 1=1{sql_filter}", filter_params)
        chunks_count = cursor.fetchone()[0]
        
        # Source counts
        source_counts = []
        for source in self.config.sources:
            cursor.execute(
                f"SELECT COUNT(*) FROM files WHERE source = ?{sql_filter}",
                [source.value] + filter_params,
            )
            file_count = cursor.fetchone()[0]
            
            cursor.execute(
                f"SELECT COUNT(*) FROM chunks WHERE source = ?{sql_filter}",
                [source.value] + filter_params,
            )
            chunk_count = cursor.fetchone()[0]
            
            source_counts.append({
                "source": source.value,
                "files": file_count,
                "chunks": chunk_count,
            })
        
        # Cache count
        cache_info = {"enabled": self.config.cache.enabled}
        if self.config.cache.enabled:
            cursor.execute("SELECT COUNT(*) FROM embedding_cache")
            cache_info["entries"] = cursor.fetchone()[0]
            cache_info["max_entries"] = self.config.cache.max_entries
        
        search_mode = "hybrid" if self.provider else "fts-only"
        
        return MemoryProviderStatus(
            backend="builtin",
            provider=self.provider.id if self.provider else "none",
            model=self.provider.model if self.provider else None,
            files=files_count,
            chunks=chunks_count,
            dirty=self._dirty,
            workspace_dir=self.workspace_dir,
            db_path=self.config.store.path,
            sources=self.config.sources,
            source_counts=source_counts,
            cache=cache_info,
            fts={"enabled": self._fts_available, "available": self._fts_available},
            vector={
                "enabled": self.config.store.vector.enabled,
                "available": self._vec_available,
                "dims": self._vector_dims,
            },
            custom={"searchMode": search_mode},
        )
    
    async def probe_embedding_availability(self) -> MemoryEmbeddingProbeResult:
        """Probe embedding provider availability"""
        if not self.provider:
            return MemoryEmbeddingProbeResult(
                ok=False,
                error="No embedding provider available (FTS-only mode)",
            )
        
        try:
            await self.provider.embed_query("ping")
            return MemoryEmbeddingProbeResult(ok=True)
        except Exception as e:
            return MemoryEmbeddingProbeResult(ok=False, error=str(e))
    
    async def probe_vector_availability(self) -> bool:
        """Probe vector search availability"""
        if not self.provider:
            return False
        if not self.config.store.vector.enabled:
            return False
        return self._ensure_vector_ready(self._vector_dims or 1536)
    
    async def close(self) -> None:
        """Close and cleanup"""
        self._closed = True
        
        # Cancel background tasks
        if self._watch_task:
            self._watch_task.cancel()
        if self._interval_task:
            self._interval_task.cancel()
        if self._debounce_timer:
            self._debounce_timer.cancel()
        
        # Close database
        if self._db:
            self._db.close()
        
        # Remove from instances
        key = f"{self.agent_id}:{self.workspace_dir}"
        with self._lock:
            if key in self._instances:
                del self._instances[key]
    
    async def start_watching(self) -> None:
        """Start file watching for automatic sync"""
        if not self.config.sync.watch:
            return
        
        async def watch_loop():
            import asyncio
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler
            
            class MemoryEventHandler(FileSystemEventHandler):
                def __init__(self, manager):
                    self.manager = manager
                    self._timer = None
                
                def _schedule_sync(self):
                    if self._timer:
                        self._timer.cancel()
                    self._timer = threading.Timer(
                        self.manager.config.sync.watch_debounce_ms / 1000,
                        lambda: asyncio.create_task(self.manager.sync(reason="watch")),
                    )
                    self._timer.start()
                
                def on_modified(self, event):
                    if not event.is_directory and event.src_path.endswith(".md"):
                        self._schedule_sync()
                
                def on_created(self, event):
                    if not event.is_directory and event.src_path.endswith(".md"):
                        self._schedule_sync()
            
            try:
                observer = Observer()
                observer.schedule(
                    MemoryEventHandler(self),
                    os.path.join(self.workspace_dir, "memory"),
                    recursive=True,
                )
                observer.start()
                
                while not self._closed:
                    await asyncio.sleep(1)
                
                observer.stop()
                observer.join()
            except Exception:
                pass
        
        self._watch_task = asyncio.create_task(watch_loop())
    
    async def start_interval_sync(self) -> None:
        """Start periodic sync"""
        if self.config.sync.interval_minutes <= 0:
            return
        
        async def interval_loop():
            while not self._closed:
                await asyncio.sleep(self.config.sync.interval_minutes * 60)
                await self.sync(reason="interval")
        
        self._interval_task = asyncio.create_task(interval_loop())
